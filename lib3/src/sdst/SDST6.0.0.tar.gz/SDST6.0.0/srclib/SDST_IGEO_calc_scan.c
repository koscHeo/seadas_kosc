/********************** filename SDST_IGEO_calc_scan.c *********************/
/*
 * SDST_IGEO_calc_scan.c contains SDST_IGEO_calc_frame() and 
 * SDST_IGEO_calc_scan_coords().
 * 
 * Revision history:
 * $Log: SDST_IGEO_calc_scan.c,v $
 * Revision 5.1  2009/06/29 15:50:40  kuyper
 * Resolved Bug 194 by validating sc_position[0] before attempting to make
 *   use of a frame.
 *
 * James Kuyper		James.R.Kuyper@nasa.gov
 *
 * Revision 1.3  1999/11/29 20:49:09  kuyper
 * Corrected upper limits on vector loops.
 *
 * Revision 1.2  1999/11/03  16:12:35  lma
 * added function SDST_IGEO_calc_scan_coords and fixed some bugs.
 *
 * Revision 1.1  1999/09/09  16:01:09  jayshree
 * Initial revision
 *
 * Revision 1.2  1999/08/11  14:37:00  jayshree
 * *** empty log message ***
 *
 * Revision 1.1  1999/07/16  19:16:19  jayshree
 * Initial revision

*/

#include "PGS_TYPES.h"
#include "PGS_SMF.h"
#include "PGS_CSC.h"
#include "PGS_MODIS_39604.h"
#include "SDST_IGEO_calc_scan.h"
#include "SDST_IGEO_get_scan.h"



static PGSt_SMF_status SDST_IGEO_calc_frame (
		           const scan_info_struct	*scan_info,
		           frame_info_struct		*frame_info)

/*
!C**************************************************************************
*
*
*!Description :
*	Calculates the parameters describing the plane containing one frame
*
*
*!Input Parameters:
*	scan_info	Information about the scan containing the frame
*
*!Output Parameters:
*	None
*
*
*!Input/Output Parameters:
*	frame_info	Information about the frame plane
*
*
*!Return Value:
*	MODIS_N_SDST_IGEO_NOTFOUND	Frame not usable otherwise
*	PGS_S_SUCCESS
*
*!Global Variables:
*	None
*
*!Called by:
*	SDST_IGEO_calc_scan_coords
*
*!Calls Function
*	None
*
*
*!Revision History
*See top of file.
*
*!Requirements:
*	CCR-468
*
*
*!Team-unique Header:
*	This software is developed by the MODIS Science Data Support
*	Team for the National Aeronautics and Space Administration, 
*	Goddard Space Flight Center, under contract NAS5-32373.
*
*
*!References and Credits:
*	HDF portions of this code were developed at the National Center
*	for Supercomputing Applications at the University of Illinois at 
*	Urbana-Champaign
*
*
!END *****************************************************************************************
*/
{

PGSt_double	disp [3];
PGSt_double	view [3];
int             i;

    /* Check for valid spacecraft position. */
    if(scan_info->sc_position[0] >= 8e6)
       return (MODIS_N_SDST_IGEO_NOTFOUND); 

    for(frame_info->first_det=0; frame_info->first_det<MAX_DETS-1; frame_info->first_det++)
        {
	  if ((scan_info->gflags[frame_info->first_det] [frame_info->iframe] ) <= INVALID_SENSOR_RANGE)
             break;
	}
	
    for(frame_info->last_det=MAX_DETS-1; frame_info->last_det>frame_info->first_det; frame_info->last_det--)
       {
     	 if ((scan_info->gflags[frame_info->last_det][frame_info->iframe]) <= INVALID_SENSOR_RANGE)
            break;
       }
		
	
    if (frame_info->first_det == MAX_DETS-1 || frame_info->last_det == frame_info->first_det)
       return (MODIS_N_SDST_IGEO_NOTFOUND); 
	
	
    for (i=0; i<3; i++) {
       disp[i] = (scan_info->position[frame_info->last_det][frame_info->iframe][i]) -
	    (scan_info->position[frame_info->first_det][frame_info->iframe][i]);
	    
       view[i] = (scan_info->position[frame_info->first_det][frame_info->iframe][i]) - 
            (scan_info->sc_position[i]) ;
    }
	
    PGS_CSC_crossProduct (disp, view, frame_info->normal);
	
	
    return (PGS_S_SUCCESS);
	
	
}


PGSt_SMF_status SDST_IGEO_calc_scan_coords(
                scan_info_struct        *scan_info,
                frame_info_struct       frame_info[])
/*
!PROLOG*************************************************************************
!Description:
       Finds the first and last usable frames for a given scan, and uses them
       to calculate the parameters used for estimating line and frame numbers.


!Input Parameters:
       None

!Output Parameters:
        frame_info      The two frames used in the calculations.

!Input/Output Parameters:
        scan_info       Information about the scan.

Return Value:
        MODIS_E_SDST_IGEO_INTERNAL          Fatal internal error
        MODIS_W_SDST_IGEO_INTERNAL          Non-fatal internal error
        MODIS_N_SDST_IGEO_NOTFOUND          Couldn't use the scan
        PGS_S_SUCCESS                       Otherwise

Global variables:       None

Called by:
        SDST_IGEO_get_scan()

Calls functions:
        SDST_IGEO_calc_frame()

Requirements:
         124, 468

!Revision History:
See top of file.

!Team-unique Header:
        This software is developed by the MODIS Science Data Support
        Team for the National Aeronautics and Space Administration,
        Goddard Space Flight Center, under contract NAS5-32373.

!END****************************************************************************
*/

{
   double      norm;
   int         i;

   if( (scan_info == NULL) || (frame_info == NULL) )
      return MODIS_E_SDST_IGEO_INTERNAL;
   
/* Find first usable frame. */
   for(frame_info[0].iframe =0; frame_info[0].iframe < scan_info->EV_frames-1;
      frame_info[0].iframe++) {

      if(SDST_IGEO_calc_frame(scan_info, &frame_info[0]) == PGS_S_SUCCESS)
         break;
   }


/* Find last usable frame. */
   for(frame_info[1].iframe = scan_info->EV_frames-1; 
      frame_info[1].iframe > frame_info[0].iframe;
      frame_info[1].iframe--) {

      if(SDST_IGEO_calc_frame(scan_info, &frame_info[1]) == PGS_S_SUCCESS)
         break;
   }


   if(frame_info[1].iframe <= frame_info[0].iframe)
      /* This scan does not contain two usable frames. */
      return MODIS_N_SDST_IGEO_NOTFOUND;


   PGS_CSC_crossProduct(frame_info[0].normal, frame_info[1].normal, 
       scan_info->T_ecr2scan[2]);
   norm = PGS_CSC_Norm(scan_info->T_ecr2scan[2]);
   if( norm <DBL_MIN)
      /* Shouldn't happen, since the two frames share the same spacecraft
       * position, and have ground positions that should be at least 1 km. apart.
       */
      return MODIS_W_SDST_IGEO_INTERNAL;

   for(i=0; i<3; i++) 
      scan_info->T_ecr2scan[2][i] /= norm;
    
   for(i=0; i<3; i++)
      scan_info->T_ecr2scan[0][i] =
	  frame_info[0].normal[i] - frame_info[1].normal[i];

   /* In normal orientation, this points toward the nadir */
   norm = PGS_CSC_Norm(scan_info->T_ecr2scan[0]);
   if( norm <DBL_MIN)
      /* Also shouldn't happen; same reason. */
      return MODIS_W_SDST_IGEO_INTERNAL;
   for(i=0; i<3; i++)
      scan_info->T_ecr2scan[0][i] /= norm;


   PGS_CSC_crossProduct(scan_info->T_ecr2scan[2], scan_info->T_ecr2scan[0],
        scan_info->T_ecr2scan[1]);

    return PGS_S_SUCCESS;

}

