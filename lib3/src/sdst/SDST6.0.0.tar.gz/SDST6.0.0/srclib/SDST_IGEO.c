#include <math.h>
#include "PGS_CSC.h"
#include "PGS_MODIS_39604.h"
#include "SDST_IGEO.h"
#include "SDST_IGEO_locate.h"
#include "SDST_IGEO_estimate_scan.h"
#include "smfio.h"

int SDST_IGEO(
	MODFILE		*geo_file,
	int		locations,
	const float32	latitude[],
	const float32	longitude[],
	float32		scan_line[][SDST_IGEO_MAX_MATCHES],
	float32		dframe[][SDST_IGEO_MAX_MATCHES],
	int16		sets[]
)
/*
!C******************************************************************************
!Description:
	SDST_IGEO is the C interface for the inverse geolocation routine. It
	looks in the specified geo_file for each of the locations given,
	identifying the matching fractional pixel indices corresponding to
	those locations.

!Input Parameters:
	geo_file        M-API file handle for the MODIS geolocation file to be
			searched for matching locations.
	locations       The number of latitude and longitude value to be matched
	latitude        The latitude of each location.
	longitude       The longitude of each location.

!Output Parameters:
	scan_line       The fractional scanline corresponding to each match
	dframe          The fractional frame number corresponding to each match
	sets            The number of matches found for each location. -1 if
			there was a per-location error.

Return Value:           MAPI_status
	MAPIOK          If all requested locations were either determined to be
			outside the bounds of the granule, or were successfully
			matched to at least one pixel.
	MFAIL           Otherwise.

Global variables:
	None

Called by:
	sdstig()        C/Fortran interface function.
	User-written C routines

Calls functions:
	modsmf()
	PGS_CSC_GEOtoECR()
	SDST_IGEO_estimate_scan_number()
	SDST_IGEO_locate_line_frame()

!Revision History:
$Log: SDST_IGEO.c,v $
Revision 5.1  2009/06/29 15:48:52  kuyper
Improved const safety.

James Kuyper	James.R.Kuyper@nasa.gov

Revision 3.1  2001/10/15 20:55:24  kuyper
Changed to search a larger number of scans, after determining that
  estimate_scan() produces a less accurate estimate than we'd hoped.

Revision 1.4  2000/04/17 20:26:54  kuyper
Corrected handling of call to estimate_scan for clearing memory.
Improved error messages.
Converted latitude and longitude to radians for call to GEOtoECR.
Improved handling of problems when geofile->filename is NULL.

 * Revision 1.3  2000/02/02  22:30:29  kuyper
 * Corrected sets to int16.
 *
 * Revision 1.2  2000/02/01  17:04:40  kuyper
 * Corrected error message.
 *
 * Revision 1.1  1999/10/05  15:11:02  kuyper
 * Initial revision
 *
* kuyper@ltpmail.gsfc.nasa.gov

Requirements:
	CCR 468

!Team-unique Header:
	This software is developed by the MODIS Science Data Support
	Team for the National Aeronautics and Space Administration,
	Goddard Space Flight Center, under contract NAS5-32373.

References and Credits:
	HDF portions developed at the National Center for Supercomputing
	Applications at the University of Illinois at Urbana-Champaign.
!END****************************************************************************
*/
{
    static graninfo_struct	graninfo={NULL};
    static char			filefunc[] = __FILE__ ", SDST_IGEO";

    double	dscan;		/* Fractional scan number estimate. */
    PGSt_double	ecr_position[3];
    unsigned	internal_errors=0U;
    int		loc;		/* Location index. */
    int		MAPI_status = MAPIOK;
    char	msgbuf[128];

    if(locations==0)
    {	/* Function is being called to release allocated memory.*/
	if(SDST_IGEO_estimate_scan_number(ecr_position, NULL, &graninfo,
	    &dscan) == MODIS_N_SDST_IGEO_NOTFOUND)
	    return MAPIOK;	/* It's NULL; it shouldn't be found. */
	else
	{
	    modsmf(MODIS_E_SDST_IGEO_INTERNAL,
		"Bad return from SDST_IGEO_estimate_scan_number(NULL)",
		filefunc);
	    
	    return MFAIL;
	}
    }

    if(locations<0)
    {
	sprintf(msgbuf, "number of locations(=%d) is negative.", locations);
	modsmf(MODIS_E_SDST_IGEO_BAD_ARG, msgbuf, filefunc);
	return MFAIL;
    }

    if(geo_file==NULL || latitude==NULL || longitude==NULL || scan_line==NULL
	|| dframe==NULL || sets==NULL)
    {
	sprintf(msgbuf, "NULL pointer - geo_file=%p latitude=%p longitude=%p\n"
	    "\tscan_line=%p dframe=%p sets=%p", (void*)geo_file,
	    (void*)latitude, (void*)longitude, (void*)scan_line, (void*)dframe,
	    (void*)sets);
	modsmf(MODIS_E_SDST_IGEO_BAD_ARG, msgbuf, filefunc);

	return MFAIL;
    }

    for(loc=0; loc<locations; loc++)
    {
	PGSt_double	adj_long;
	int		mat;		/* match index. */
	/* Status returned by subroutines. */
	PGSt_SMF_status	status = PGS_S_SUCCESS;
	/*Worst error status for this location*/
	PGSt_SMF_status	loc_stat = PGS_S_SUCCESS;
	int32	bottom;	/* Starting scan number.		*/
	int32	top;	/* One more than ending scan number.	*/
	int32	iscan;	/* Integral scan number guess.		*/

	sets[loc]=-1;

	/* Initialize to safe values - these may be used as indices. */
	for(mat=0; mat<SDST_IGEO_MAX_MATCHES; mat++)
	{
	    scan_line[loc][mat] = 0.0F;
	    dframe[loc][mat] = 0.0F;
	}

	if(fabs((double)latitude[loc]) > 90.0)
	{
	    sprintf(msgbuf, "latitude[%d]=%f is largeer than 90.0",
		loc, latitude[loc]);
	    modsmf(MODIS_E_SDST_IGEO_BAD_ARG, msgbuf, filefunc);

	    MAPI_status = MFAIL;
	    continue;
	}

	adj_long = (double)longitude[loc] -
	    360.0*floor( ((double)longitude[loc]+180.0)/360.0 );
	if(PGS_CSC_GEOtoECR(DEG2RAD*adj_long,
	    DEG2RAD*(PGSt_double)latitude[loc], 0.0, "WGS84", ecr_position)
	    != PGS_S_SUCCESS)
	{
	    internal_errors++;
	    MAPI_status = MFAIL;
	    continue;
	}

	status = SDST_IGEO_estimate_scan_number(ecr_position, geo_file,
	    &graninfo, &dscan);
	switch(status)
	{
	case PGS_S_SUCCESS:
	    bottom = (int)floor(dscan-4);
	    top = (int)ceil(dscan+4);
	    sets[loc] = 0;

	    for(iscan=bottom; iscan<top && sets[loc]<SDST_IGEO_MAX_MATCHES;
		iscan++)
	    {
		if(iscan >= graninfo.first_scan && iscan < graninfo.scans)
		{
		    status = SDST_IGEO_locate_line_frame(geo_file,
			iscan, ecr_position,
			&scan_line[loc][sets[loc]], &dframe[loc][sets[loc]]);
		    if(status == PGS_S_SUCCESS)
			sets[loc]++;
		    else if(loc_stat < status)
			loc_stat = status;
		}
	    }
	    break;

	case MODIS_N_SDST_IGEO_NOTFOUND:
	    sets[loc] = 0;
	    break;

	case MODIS_E_SDST_IGEO_INTERNAL:
	    /* There's nothing the user can do about these, no need to give
	     * details, only a final count.
	     */
	    internal_errors++;
	    MAPI_status = MFAIL;
	    break;

	default:
	    loc_stat = status;
	    break;
	}

	if(sets[loc]<=0 && loc_stat > MODIS_N_SDST_IGEO_NOTFOUND)
	{
	    /* The failure to match involves at least one error condition */
	    sprintf(msgbuf, "for location %d", loc);
	    modsmf(loc_stat, msgbuf, filefunc);
	    sets[loc] = -1;
	    MAPI_status = MFAIL;
	}

	if(loc_stat == MODIS_E_SDST_IGEO_BAD_ARG)
	    /* If this locations failed for this reason, then all the
	     * locations will fail also - avoid creating multiple messages.*/
	    while(++loc < locations)
		sets[loc] = -1;
    }

    if(internal_errors)
    {
	sprintf(msgbuf, "count=%u", internal_errors);
	modsmf(MODIS_E_SDST_IGEO_INTERNAL, msgbuf, filefunc);
    }

    return MAPI_status;
}

