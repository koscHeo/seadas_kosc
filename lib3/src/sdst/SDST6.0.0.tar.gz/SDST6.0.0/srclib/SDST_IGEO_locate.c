/******************************************************************************
 *!Revision History:
 * $Log: SDST_IGEO_locate.c,v $
 * Revision 1.4  2000/04/21 16:37:35  kuyper
 * Corrected initialization of newdist2.
 *
 * Revision 1.3  1999/11/29  20:53:54  kuyper
 * Changed pnorm test to use MAX_RATIO.
 * Corrected indices to int16.
 * Changed variable names and initialization to indicate squared distances,
 *   rather than just distances.
 * Switched branched on if(j) tests.
 *
 * Revision 1.2  1999/10/08  20:53:36  kuyper
 * Removed duplicated MAX_DIST from pnorm test.
 * Renamed DISTANCE2 to DIST_SQUARED.
 *
 * Revision 1.1  1999/09/28  21:55:08  kuyper
 * Initial revision
 *
 * kuyper@ltpmail.gsfc.nasa.gov
 ******************************************************************************
 */

#include <math.h>
#include "PGS_CSC.h"
#include "PGS_MODIS_39604.h"
#include "SDST_IGEO_locate.h"
#include "SDST_IGEO_get_scan.h"
#include "SDST_IGEO_line_frame.h"

static double	ecr_diff[3];

#define DIST_SQUARED(pos_ecr1,pos_ecr2) \
(ecr_diff[0] = (pos_ecr2)[0] - (pos_ecr1)[0], \
ecr_diff[1] = (pos_ecr2)[1] - (pos_ecr1)[1], \
ecr_diff[2] = (pos_ecr2)[2] - (pos_ecr1)[2], \
ecr_diff[0]*ecr_diff[0]+ecr_diff[1]*ecr_diff[1]+ecr_diff[2]*ecr_diff[2])
#define MAX_DIST	600000.0	/* Upper limit for distance. */
#define MAX_AREA	10000000.0	/* Maximum size (m^2) of a pixel. */

/* This limit is needed only to avoid overflow in calculations; set it somewhat
 * larger than DBL_MAX/(radius of Earth in meters) to achieve that purpose.
 * However, there's no plausible reason for the slope to be much higher than
 * 1 + (MAX_DIST/radius of Earth)^2.
 */
#define MAX_RATIO	2.0

static double SDST_IGEO_check_neighbor
(
	scan_info_struct	* const scan_info,
	PGSt_double		const ecr_position [3],
	int16			indices[2][2]
)
/*
!PROLOG*************************************************************************
!Description:
	Searches scan_info.position for the entry adjacent to indices[0] which
	is closest the requested position, and returns it in indices[1].

!Input Parameters:
	scan_info       Scan level information needed by inverse geolocation
	ecr_position    ECR coordinates for a requested position.

!Output Parameters:
	None

!Input/Output Parameters:
	indices         Line and frame indices into scan_info.position, for the
			previous and next best pixels.

Return Value:           distance2
	The distance squared between the best pixel found and ecr_position, or
	MAX_DIST if no good neighboring pixels are found.

Global variables:
	None

Called by:
	SDST_IGEO_locate_line_frame()

Routines called:
	None

!Revision History:
See top of file.

Requirements:
	CCR 468

!Team-unique Header:
	This software is developed by the MODIS Science Data Support
	Team for the National Aeronautics and Space Administration,
	Goddard Space Flight Center, under contract NAS5-32373.

!END****************************************************************************
*/

{
    double	distance2=MAX_DIST*MAX_DIST;
    int		i;
    double	tdist2;
    int16	max_index[2]={MAX_DETS,0};
    int16	min_index[2]={0,0};
    int16	pos[2];
    max_index[1] = scan_info->EV_frames;

    /* Limit search to points adjacent to current position, but not outside
     * valid range.
     */
    for(i=0; i<2; i++)
    {
	if(indices[0][i]-1 > min_index[i])
	    min_index[i] = (int16)(indices[0][i]-1);
	if(indices[0][i]+2 < max_index[i])
	    max_index[i] = (int16)(indices[0][i]+2);
    }

    /* Find the ground position closest to the requested point. */
    for(pos[0]=min_index[0]; pos[0]< max_index[0]; pos[0]++)
    {
	for(pos[1]=min_index[1]; pos[1]< max_index[1]; pos[1]++)
	{
	     if(pos[0] != indices[0][0] || pos[1] != indices[0][1])
	     {
		 tdist2 = DIST_SQUARED(scan_info->position[pos[0]][pos[1]],
		      ecr_position);
		 /* Note: bad data has been given positions of <0,0,0>, so
		  * tdist2 will be large: it will never be smaller than current
		  * best position.
		  */
		 if(tdist2 < distance2)
		 {
		      distance2 = tdist2;
		      indices[1][0] = pos[0];
		      indices[1][1] = pos[1];
		 }
	     }
	}
    }

    return distance2;
}

typedef struct {
	int16 origin[2];
	int16 track_off[2];
	int16 scan_off[2];
}	triangle_struct;

static PGSt_SMF_status SDST_IGEO_make_triangle
(
	PGSt_double		const ecr_position[3],
	scan_info_struct	const * const scan_info,
	int16			indices[2][2],
	triangle_struct		* const triangle
)

/*
!PROLOG*************************************************************************
!Description:
        From among the pixels adjacent to both indices[0][] and indices[1][],
        this function chooses the one that whose ground position is closest to
        ecr_position[]. It is assumed that indices[0] and indices[1] differ from
        each other by 1 in at least one of the two indices, and by no more than
        1 in either index. Those assumptions are not required for the safe
        execution of this routine, only for it's correct execution. They are
        therefore not checked - they are the responsibility of the calling
        function.
        The resulting triangle will have one edge parallel to each index
        direction. The points of that triangle are copied to 'triangle' in the
        order that reflects the oriention of the sides they connect.

!Input Parameters:
        ecr_position    The ECR coordinates of the requested position.
        scan_info       Scan level information needed by inverse geolocation.
        indices          The indices of the two pixels already chosen.

!Output Parameters:
        triangle        The two pixels already chosen, plus the newly selected
                        one, organized by the orientation of the sides they
                        connect.

Return Value:
        MODIS_E_SDST_IGEO_INTERNAL   If any argument is NULL
        MODIS_N_SDST_IGEO_NOTFOUND   If an acceptable third point could not be found.
        PGS_S_SUCCESS           Otherwise

Global variables:
        None

Called by:
        SDST_IGEO_locate_line_frame()

Calls functions:
        None

!Revision History:
See top of file.

Requirements:
	CCR 468

!Team-unique Header:
        This software is developed by the MODIS Science Data Support
        Team for the National Aeronautics and Space Administration,
        Goddard Space Flight Center, under contract NAS5-32373.


!END****************************************************************************
*/
{
    double	bestdist2=MAX_DIST*MAX_DIST, dist2;
    int		i,j;
    int16	max_index[2]={1,1};
    int16	min_index[2]={MAX_DETS-2,0};
    int16	out[2];
    int16	pos[2];

    /* These initial values are chosen to guarantee that the loop doesn't go 
     * over the edges of the scan.
     */
    min_index[1] = (int16)(scan_info->EV_frames-2);

    /* Set the limits for the search. */
    for(i=0; i<2; i++)
	for(j=0; j<2; j++)
	{
	    if(indices[i][j] > max_index[j])
		max_index[j] = indices[i][j];
	    if(indices[i][j] < min_index[j])
		min_index[j] = indices[i][j];
	}

    /* Common neighor means pixels within +/-1 of both points, on both axes.*/
    for(pos[0]=(int16)(max_index[0]-1); pos[0]<=min_index[0]+1; pos[0]++)
	for(pos[1]=(int16)(max_index[1]-1); pos[1]<=min_index[1]+1; pos[1]++)
	    if( (pos[0] != indices[0][0] || pos[1] != indices[0][1]) &&
		(pos[0] != indices[1][0] || pos[1] != indices[1][1]) ) 
	    {
		/* If pos not the same as either pair of indices.*/
		dist2 = DIST_SQUARED(scan_info->position[pos[0]][pos[1]],
		      ecr_position);
		if(dist2 < bestdist2)
		{
		    bestdist2 = dist2;
		    memcpy(out, pos, sizeof(out));
		}
	     }

    if(bestdist2 >= MAX_DIST*MAX_DIST)
	return MODIS_N_SDST_IGEO_NOTFOUND;

    /* Find out whether either of the input points is on the same line or
     * frame as 'out'.
     */
    for(i=0; i<2; i++)
    {
	for(j=0; j<2 && indices[i][j] != out[j]; j++);

	if(j<2)
	    break;
    }

    /* If indices[0] and indices[1] were in fact adjacent pixels, then together
     * with 'out' they now form a small isoceles right triangle, with two sides
     * oriented along the scan and track directions. Specifically, the line
     * connecting indices[i] to 'out' runs along dimension 'j'.
     * The following logic is where assumptions are made about the proximity of
     * indices[0] and indices[1]. However, even if those assumptions are
     * violated, no array bounds will be violated.
     *
     * Check whether the OTHER input point is also lined up with 'out' on the
     * OTHER axis.
     */
    if(indices[1-i][1-j] == out[1-j])
    {
	 /* If so, then 'out' is opposite the long side of the triangle. */
	 memcpy(triangle->origin, out, sizeof(out));
	 if(j)
	 {
	     /* indices[i] is lined up with 'out' in the track direction. */
	     memcpy(triangle->track_off, indices[i],
		 sizeof(triangle->track_off));
	     memcpy(triangle->scan_off, indices[1-i],
		 sizeof(triangle->scan_off));
	 }
	 else
	 {
	     /* indices[i] is lined up with 'out' in the scan direction. */
	     memcpy(triangle->scan_off, indices[i],
		 sizeof(triangle->scan_off));
	     memcpy(triangle->track_off, indices[1-i],
		 sizeof(triangle->track_off));
	 }
    }
    else
    {
	/* If not, then indices[i] must be lined up with indices[1-i], and is
	 * therefore the vertex opposite the long side of the triangle.
	 */
	memcpy(triangle->origin, indices[i], sizeof(triangle->origin));
	if(j)
	{
	    /* 'out' is lined up with indices[i] in the track direction. */
	    memcpy(triangle->track_off, out, sizeof(out));
	    memcpy(triangle->scan_off, indices[1-i],
		sizeof(triangle->track_off));
	}
	else
	{
	    /* 'out' is lined up with indices[i] in the scan direction. */
	    memcpy(triangle->scan_off, out, sizeof(out));
	    memcpy(triangle->track_off, indices[1-i],
		sizeof(triangle->track_off));
	}
    }

    return PGS_S_SUCCESS;
}

PGSt_SMF_status SDST_IGEO_locate_line_frame
(
	MODFILE		* const geo_file,
	int32		const iscan,
	PGSt_double	const ecr_position[3],
	float32		*const scan_line,
	float32		*const dframe
)

/*
!PROLOG*************************************************************************
!Description:
        Estimates the fractional scan-line and frame numbers corresponding to
        the closest point in a given scan to the requested position.

!Input Parameters:
        geo_file        The M-API file handle for the geolocation file.
        iscan           The scan number to be searched.
        ecr_position    The ECR coordinates of the requested location.

!Output Parameters:
        scan_line       The fractional scan-line number
        dframe          The fractional frame number. 

Return Value:
        MODIS_E_SDST_IGEO_BAD_DATA*     The geolocation file is corrupt.
        MODIS_E_SDST_IGEO_READ*         I/O error while reading geolocation file.
        MODIS_E_SDST_IGEO_INTERNAL  Fatal internal error in self or subroutines
        MODIS_E_SDST_IGEO_MEM*          Insufficient memory.
        MODIS_W_SDST_IGEO_INTERNAL* Non-fatal internal error.
        MODIS_N_SDST_IGEO_NOTFOUND  Couldn't use the scan
        PGS_S_SUCCESS
* - passed on from subroutines; not returned directly from this function.

Global variables:
        None

Called by:
        inverse_geolocate

Routines called:
        PGS_CSC_dotProduct()
        PGS_CSC_crossProduct()
        SDST_IGEO_get_scan()
        SDST_IGEO_estimate_line_frame()
        SDST_IGEO_check_neighbors()
        SDST_IGEO_make_triangle()

!Revision History:
See top of file.

Requirements:
        CCR 468

!Team-unique Header:
        This software is developed by the MODIS Science Data Support
        Team for the National Aeronautics and Space Administration,
        Goddard Space Flight Center, under contract NAS5-32373.

!END****************************************************************************
*/
{
    scan_info_struct	*scan_info;
    triangle_struct	triangle;
    PGSt_SMF_status	status;
    PGSt_double		delta[3], scrosst[3];
    PGSt_double		vscan[3], vtrack[3];
    PGSt_double		*scan_off, *track_off, *origin;
    double		curdist2, newdist2;
    double		dline, denom;
    double		f,s;
    double		onorm, pnorm;
    double		sdotd, sdots, tdotd, tdots, tdott;
    int16		indices[2][2];
    int			i;

    if(geo_file == NULL || ecr_position == NULL
	|| scan_line == NULL || dframe == NULL)
	return MODIS_E_SDST_IGEO_INTERNAL;

    status = SDST_IGEO_get_scan(geo_file, iscan, &scan_info);
    if(status != PGS_S_SUCCESS)
	return status;

    status = SDST_IGEO_estimate_line_frame(scan_info, ecr_position, &dline,
	dframe);
    if(status != PGS_S_SUCCESS)
	return status;

    /* find the nearest valid line number. */
    indices[1][0] = (int16)floor(dline+0.5);
    if(indices[1][0] < 0)
	indices[1][0] = 0;
    else if(indices[1][0] >= MAX_DETS)
	indices[1][0] = MAX_DETS-1;

    /* find the nearest valid frame number. */
    indices[1][1] = (int16)floor((double)*dframe+0.5);
    if(indices[1][1] < 0)
	indices[1][1] = 0;
    else if(indices[1][1] >= scan_info->EV_frames)
	indices[1][1] = (int16)(scan_info->EV_frames-1);

    newdist2 = DIST_SQUARED(scan_info->position[indices[1][0]][indices[1][1]],
		      ecr_position);	/* ?? */
    /* search for nearest grid point. */
    do
    {
	 curdist2 = newdist2;
	 memcpy(indices[0],indices[1], 2*sizeof(indices[0][0]));
	 newdist2 = SDST_IGEO_check_neighbor(scan_info, ecr_position, indices);
    } while(newdist2 < curdist2);

    if(newdist2 >= MAX_DIST*MAX_DIST || curdist2 >= MAX_DIST*MAX_DIST)
	/* Not enough good points to support [inter|extra]polation */
	return MODIS_N_SDST_IGEO_NOTFOUND;

    status = SDST_IGEO_make_triangle(ecr_position, scan_info, indices,
	&triangle);
    if(status != PGS_S_SUCCESS)
	return status;

    origin = scan_info->position[triangle.origin[0]][triangle.origin[1]];

    track_off = scan_info->position[triangle.track_off[0]]
	[triangle.track_off[1]];
    for(i=0; i<3; i++)
	vtrack[i] = track_off[i] - origin[i];
    tdott = PGS_CSC_dotProduct(vtrack, vtrack, 3);

    scan_off = scan_info->position[triangle.scan_off[0]][triangle.scan_off[1]];
    for(i=0; i<3; i++)
	vscan[i] = scan_off[i] - origin[i];

    sdots = PGS_CSC_dotProduct(vscan, vscan, 3);
    tdots = PGS_CSC_dotProduct(vtrack, vscan, 3);
    denom = sdots*tdott-tdots*tdots;

    if(fabs(denom) < MAX_AREA/DBL_MAX)
	/* The scan and track directions are nearly parrallel on the ground. */
	return MODIS_N_SDST_IGEO_NOTFOUND;

    PGS_CSC_crossProduct(vscan, vtrack, scrosst);

    pnorm = PGS_CSC_dotProduct((PGSt_double*)ecr_position, scrosst, 3);
    onorm = PGS_CSC_dotProduct(origin, scrosst, 3);

    if(fabs(pnorm) < fabs(onorm)/MAX_RATIO)
	/* The slope of the chosen triangle is essentially vertical */
	return MODIS_E_SDST_IGEO_INTERNAL;

    /* project into the plane of the triangle, and calculate offset from
     * origin.
     */
    for(i=0; i<3; i++)
	delta[i] = ecr_position[i]*onorm/pnorm - origin[i];

    sdotd = PGS_CSC_dotProduct(vscan, delta, 3);
    tdotd = PGS_CSC_dotProduct(vtrack, delta, 3);

    /* Calculate the fractional pixel offset from origin.*/
    f = (sdotd*tdott - tdotd*tdots)/denom;
    s = (tdotd*sdots - sdotd*tdots)/denom;

    if(s<-0.5 || s>1.5 || f<-1.0 || f>2.0)
	/* Limit the range of extrapolation - the permitted range is greater in
	 * the scan direction because frames overlap.
	 */
	return MODIS_N_SDST_IGEO_NOTFOUND;

    *scan_line = (float32)(10.0*(double)iscan + (double)triangle.origin[0]
	+ s*(double)(triangle.track_off[0]-triangle.origin[0]));
    *dframe = (float32)((double)triangle.origin[1]
	+ f*(double)(triangle.scan_off[1]-triangle.origin[1]));

    return PGS_S_SUCCESS;
}

