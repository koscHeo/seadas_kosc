/* start of modsmf.c */

/* MODSMF module */
#include <time.h>
#include "smfio.h"

void modsmf(
	PGSt_SMF_code	mnemonicstring,
	const char 	*infostring,
	const char 	*functionstring
)
/*
!C***************************************************************************

!Description:

  This module writes errors and messages through the SDP toolkit to
  LogStatus.  As input it acccepts an error mnemonic, string containing
  user information, and a string containing the function name and module
  where the error/message occurs.

!Input Parameters:
  PGSt_SMF_code mnemonicstring      SMF message mnemonic
  char *infostring                  String containing info to be written to 
                                    LogStatus
  char *functionstring              String containing function/module name
                                    to be written to LogStatus

!Output Parameters:
  None

!Revision History:
 * $Log: modsmf.c,v $
 * Revision 5.1  2009/06/27 19:25:51  kuyper
 * Removed code that relied upon unportable assumption that the expansion of
 *   NULL is an expression of integer type.
 * Improved const safety.
 * Removed unnecessary variable.
 *
 * James Kuyper		James.R.Kuyper@nasa.gov
 *
 * Revision 1.5  2001/08/29 18:46:02  pliu
 * Changed function declaration to standard format.
 *
 * Revision 1.4  2001/08/06 15:41:14  pliu
 * Renamed filename smf.c to modsmf.c.
 *
 * Revision 1.3  1999/09/28 00:03:42  solanki
 * Cleaned up and working on all platforms.
 *
 * Revision 1.1  1999/09/03  21:48:51  solanki
 * Initial revision
 *
 * Revision 1.2  1998/06/26  16:32:00  jayshree
 * Changed function - return to calling program on failure
 * instead of exit(1).  Removed test for fatal error.
 *
 *
 * Revision 1.1  1997/07/21  16:43:00  kuyper
 * Baselined Version 1
 *
 * Revision 1.7  1997/04/18  15:32:54  fhliang
 * added log header to prolog (L.43).
 *
 * Revision 1.6  1997/03/26 18:21:31  fhliang
 * Initial revision of SDST delivery of smf.c.
 *
   Revision 1.5 1995/07/31
   P. Fisher/SDST
   Removed AT_SCF functionality to meet ECS requirements.

   Revision 1.4 1996/05/10
   P. Fisher/SDST
   Changed function to always return 1 on failure-exit, per
   MODIS standards and guidelines.

   Revision 1.3 1995/11/30
   P. Fisher/SDST
   Bug fix from previous version

   Revision 1.2 1995/11/28
   R. Wolfe/MODIS Science support
   Added AT_SCF functionality to notify user if toolkit fails

   Revision 1.1  1995/07/12  19:27:46  fisher
   Initial revision
 

!Team-unique Header:
  This software is modified by the MODIS Science Data Support
  Team for the National Aeronautics and Space Administration,
  Goddard Space Flight Center, under contract NAS5-32373.

!References and Credits:
  Written by Paul S. Fisher

    Research and Data Systems Corporation
    SAIC/GSC MODIS Support Office
    Seabrook MD 20706  

  Modifications by Robert E. Wolfe
      MODIS Land Team Support Group     
      Hughes STX
      Greenbelt, MD 20770  

!Design Notes:

  The determination of time is through native C function(s).

  Designed to run with seed file format of:
    MODIS_X_MNEMONIC STRING %sStatic Message.  %s

  Example of function call:

  modsmf(MODIS_X_MNEMONIC_STRING, "user message string", "function, 
                                                     module.c string");

  -- The mnemonic string must be identical to one contained in an included 
       seed file.
  -- The user message string can contain anything that needs to be written
       to the log(s).
  -- The function, module.c string should contain "the name of the function,
       the name of the module".

					      
Externals:
  constants:
       PGS_SMF_MAX_MSGBUF_SIZE                 (PGS_SMF.h)
       PGS_TRUE                                (PGS_SMF.h)
       PGS_FALSE                               (PGS_SMF.h)
       PGS_E_UNIX                              (PGS_SMF.h)
       PGS_E_UNDEFINED_CODE                    (PGS_SMF.h)
       PGS_SMF_E_LOGFILE                       (PGS_SMF.h)
       PGS_S_SUCCESS                           (PGS_SMF.h)
       NULL                                    <stdio.h>

  typedefs:
       PGSt_SMF_status                         (PGS_SMF.h)
       struct tm                               (smfio.h)<time.h>
       time_t                                  (smfio.h)<time.h>

  functions:
       PGS_SMF_GetMsgByCode                    (PGS_SMF.h)
       PGS_SMF_SetDynamicMsg                   (PGS_SMF.h)
       exit                                    <stlib.h>
       sprintf                                 <stdio.h>
       time                                    (smfio.h)<time.h>
       localtime                               (smfio.h)<time.h>
       asctime                                 (smfio.h)<time.h>



!END
*****************************************************************************/

{
  char message[PGS_SMF_MAX_MSGBUF_SIZE]={0};    /* holds the message string 
					       associated with
					       the error code returned 
					       by GetMsg */

  char buf[PGS_SMF_MAX_MSGBUF_SIZE]={0};        /* Holds a concatenated dynamic
					       message string */


  time_t t=time(NULL);				/* Calculate timestamp */
  struct tm *local=(struct tm *)localtime(&t);	/* Time functions */

  /* Get message from seed file based on error mnemonic */
  if(PGS_SMF_GetMsgByCode(mnemonicstring, message)!=PGS_S_SUCCESS)
      return;

  /* Concatenate timestamp, and user massage w/ buffer message */
  sprintf(buf, message, asctime(local), infostring);
  
  /* Write message to LogStatus */
  PGS_SMF_SetDynamicMsg(mnemonicstring, buf, (char*)functionstring);
}


/* End of modsmf.c */
