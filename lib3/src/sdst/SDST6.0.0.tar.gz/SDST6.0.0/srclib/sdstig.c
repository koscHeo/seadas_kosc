#include <string.h>
#include "mapic.h"
#include "hdfi.h"
#include "PGS_MODIS_39604.h"
#include "SDST_IGEO.h"
#include "smfio.h"

int FNAME(sdstig)(
	intf  [MODFILLEN],
	intf* ,
	float32 [],
	float32 [],
	float32 [][SDST_IGEO_MAX_MATCHES],
	float32 [][SDST_IGEO_MAX_MATCHES],
	intf  for_sets[]
);	/* will trigger error meessage if float != float32. */

int FNAME(sdstig)(
	intf  for_file[MODFILLEN],
	intf* for_locs,
	float for_lat[],
	float for_lon[],
	float for_scan_line[][SDST_IGEO_MAX_MATCHES],
	float for_frame[][SDST_IGEO_MAX_MATCHES],
	intf  for_sets[]
)
/*
!C*************************************************************************
!Description:
        This is the C function which is written to be callable as a function
        from Fortran. It is a wrapper for the MODIS inverse geolocation routine.
        Its true name is the expansion of the FNAME(sdstig) macro. It converts
        between Fortran data types and the HDF data types required by SDST_IGEO.

!Input Parameters:
        for_file        Array used by Fortran M-API routines to keep track of
                        the geolocation file.
        for_locs        The number of latitude and longitude value to be matched
        for_lat         The latitude of each location.
        for_lon         The longitude of each location.


!Output Parameters:
        for_scan_line   The fractional scanline corresponding to each match.
        for_frame       The fractional frame number corresponding to each match
        for_sets        The number of matches found for each location. -1 if
                        there was a per-location error.

Return Value:           for_status
        MFAIL           If any pointer argument is NULL, or SDST_IGEO() returns
                        MFAIL
        MAPIOK          Otherwise

Global variables:
        None

Called by:
        User-written Fortran routines

Calls functions:
        SDST_IGEO()
        modsmf()


!Revision History:
$Log: sdstig.c,v $
Revision 1.4  2000/06/07 20:14:55  kuyper
Inserted declaration that will cause error message if float!=float32.
Made implicit conversion explicit.

 * Revision 1.3  2000/04/21  15:53:47  fhliang
 * removed dereferencing operator * from for_locs in
 * the logic for input NULL pointer arguments.
 *
 * Revision 1.2  2000/03/01  19:23:47  fhliang
 * updated after code walkthrough
 *
 * Revision 1.1  2000/02/25  19:15:47  fhliang
 * Initial revision
 *

Requirements:
        CCR 468

!Team-unique Header:
        This software is developed by the MODIS Science Data Support
        Team for the National Aeronautics and Space Administration,
        Goddard Space Flight Center, under contract NAS5-32373.

!References and Credits:
        HDF portions developed at the National Center for Supercomputing
        Applications at the University of Illinois at Urbana-Champaign.

!Design Notes:
  Externals
  ---------
  MAPIOK			(mapi.h, included in mapic.h)
  MFAIL				(mapi.h, included in mapic.h)
  MODFILLEN			(mapic.h)
  MODIS_E_SDST_IGEO_BAD_ARG	(PGS_MODIS_39604.h)
  modsmf()			(smfio.h)
  P_ADDR			(mapic.h)
  SDST_IGEO()			(SDST_IGEO.h)
  SDST_IGEO_MAX_MATCHES		(SDST_IGEO.h)

!END*****************************************************************************/

{
    static char filefunc[] = __FILE__ ", sdstig";
    int16    *sets = NULL;
    MODFILE *geo_file;
    char     msgbuf[128];
    int      loc;

    intf  for_status;


    if(for_file==NULL || for_locs==NULL || for_lon==NULL || for_lat==NULL
       || for_sets==NULL || for_scan_line==NULL || for_frame==NULL)
    {
        sprintf(msgbuf, "\nNULL pointer - file=%p locs=%p lon=%p lat=%p\n"
            "\t       sets=%p scan_line=%p frame=%p", (void*)for_file, (void*)for_locs,
             (void*)for_lon, (void*)for_lat, (void*)for_sets, (void*)for_scan_line,
             (void*)for_frame);
        modsmf(MODIS_E_SDST_IGEO_BAD_ARG, msgbuf, filefunc);

        return MFAIL;
    }

/* to fill in geo_file from the locations starting at for_file[P_ADDR] */
    memcpy(&geo_file, &for_file[P_ADDR], sizeof(geo_file));

/* Note: the following function call will work only if float and float32 are the
 * same. It also assumes that intf is no smaller than int16, and that an 'intf*'
 * will point to memory correctly aligned to hold an int16. These assumptions
 * are true on all the platforms we currently need to port to. Ideally, the code
 * should be written so as to produce compile-time error messages if ported to
 * a platform where any of these assumptions is false.
 */
    sets = (int16*)for_sets; /* converted to the right type */
    for_status = SDST_IGEO(geo_file, *for_locs, for_lat, for_lon,
                           for_scan_line, for_frame, sets);

/* intf will probably be bigger than int16 - must work backwards.*/
    if (*for_locs > 0)
    {
    loc = *for_locs - 1;
    while (loc >= 0)
	{
	for_sets[loc] = (intf)sets[loc];
	loc--;
	} /* end while */
    } /* end if */

return for_status;
}
