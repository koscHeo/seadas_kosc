/********************** filename SDST_IGEO_get_gran.c *********************/
/*
 * SDST_IGEO_get_gran.c contains SDST_IGEO_load_gran(), SDST_IGEO_get_graninfo()
 * and SDST_IGEO_calc_gran_coords().
 * 
 * Revision History:
 * $Log: SDST_IGEO_get_gran.c,v $
 * Revision 6.1  2010/07/14 17:12:09  kuyper
 * Removed useless 'const' from two-dimensional array argument.
 *
 * Revision 1.3  2000/03/28 15:26:43  fhliang
 * corrected message in msgbuf used to call modsmf() for
 * MODIS_E_SDST_IGEO_BAD_ARG in SDST_IGEO_load_gran().
 *
 * Revision 1.2  1999/12/16  15:36:34  lma
 * updated after unit test
 *
 * Revision 1.1  1999/12/07  20:34:50  lma
 * Initial revision
 *
*/


#include "PGS_TYPES.h"
#include "PGS_SMF.h"
#include "PGS_CSC.h"
#include "PGS_MODIS_39604.h"
#include "SDST_IGEO_calc_scan.h"
#include "SDST_IGEO_get_scan.h"
#include "SDST_IGEO_estimate_scan.h"
#include "mapi.h"
#include "mapiL1Bgeo.h"
#include "smfio.h"



static PGSt_SMF_status SDST_IGEO_load_gran(
                MODFILE                 *geo_file,
		graninfo_struct  	*graninfo)

/*
!C**************************************************************************
*!Description :
*	Subroutine of inverse geolocation routine which reads the granule 
*       level information needed from the geolocation file identified by
*       geo_file.
*
*
*!Input Parameters:
*	geo_file                M-API file handle of geolocation file
*
*!Output Parameters:
*	graninfo        Granule level information needed by inverse geolocation.

*
*
*!Return Value:
*       MODIS_E_SDST_IGEO_BAD_ARG   The geolocation file's name is missing
*       MODIS_E_SDST_IGEO_BAD_DATA  The geolocation file contains corrupt data
*       MODIS_E_SDST_IGEO_MEM       Insufficient memory to copy filename.
*       MODIS_E_SDST_IGEO_READ      I/O Error while reading geolocation file
*       PGS_S_SUCCESS               Otherwise
*
*!Global Variables:
*	None
*
*!Called by:
*	SDST_IGEO_get_graninfo()
*
*!Routines called:
*       modsmf()
*       getMODISarray
*       getMODISfileinfo
*
*!Revision History:
*See top of file.
*
*
*!Requirements:
*	CCR-468
*
*
*!Team-unique Header:
*	This software is developed by the MODIS Science Data Support
*	Team for the National Aeronautics and Space Administration, 
*	Goddard Space Flight Center, under contract NAS5-32373.
*
*
*!References and Credits:
*	HDF portions of this code were developed at the National Center
*	for Supercomputing Applications at the University of Illinois at 
*	Urbana-Champaign
*
*
!END ***************************************************************************
*/
{
   char            datatype[DATATYPELENMAX] = I32;
   long            n_elements = 1;
   char            msgbuf[128];
   long            dimsizes[2];
   long            start[2]={0,0};



   if(geo_file == NULL){
      free(graninfo->filename);
      return PGS_S_SUCCESS;
   }
     
   if(geo_file->filename == NULL){
      strcpy(msgbuf, "geolocation filename is NULL");
      modsmf(MODIS_E_SDST_IGEO_BAD_ARG, msgbuf, __FILE__ ", SDST_IGEO_load_gran");
      return MODIS_E_SDST_IGEO_BAD_ARG;
   }

   
   graninfo->filename = realloc(graninfo->filename, strlen(geo_file->filename)+1);

   if(graninfo->filename == NULL){
      modsmf(MODIS_E_SDST_IGEO_MEM, "", __FILE__ ", SDST_IGEO_load_gran");
      return MODIS_E_SDST_IGEO_MEM;
   }


   strcpy(graninfo->filename, geo_file->filename);


   if(getMODISfileinfo(geo_file, M03NUMBER_OF_SCANS, datatype,
                              &n_elements, &graninfo->scans) != MAPIOK ){
      modsmf(MODIS_E_SDST_IGEO_READ, geo_file->filename, __FILE__ ", SDST_IGEO_load_gran");
      return MODIS_E_SDST_IGEO_READ;
   }

   if((graninfo->scans <0 )|| (graninfo->scans > MAX_SCANS)){
      sprintf(msgbuf, " %s = %ld ", M03NUMBER_OF_SCANS, (long)graninfo->scans);
      modsmf(MODIS_E_SDST_IGEO_BAD_DATA, msgbuf, __FILE__ ", SDST_IGEO_load_gran");
      return MODIS_E_SDST_IGEO_BAD_DATA;
   }

   if(graninfo->scans == 0)
      /* 0 is a valid number of scans */
      /* Higher level routines will note that it's too few scans to use. */
      return PGS_S_SUCCESS;
  
   
   dimsizes[0] = (long)graninfo->scans;
   dimsizes[1]= 1;
   if(getMODISarray(geo_file, M03GEO_SCAN_QUALITY, "", start, dimsizes,
                              graninfo->quality)!= MAPIOK ){
      modsmf(MODIS_E_SDST_IGEO_READ, geo_file->filename, __FILE__ ", SDST_IGEO_load_gran");
      return MODIS_E_SDST_IGEO_READ;
   }


   return PGS_S_SUCCESS;
}







static PGSt_SMF_status SDST_IGEO_calc_gran_coords(
	scan_info_struct	*scan_info[2],
	graninfo_struct		*graninfo)

/*
!C******************************************************************************
*
*
*!Description:
*       Subroutine of the inverse geolocation routine which calculates the
*       parameters describing the granule-oriented coordinate system which is
*       used to estimate the scan number.
*
*
*!Input Parameters:
*       scan_info       A pair of pointers to information about the first and
*                       last usable scans in the granule.
*
*!Output Parameters:
*       None
*
*   
*!Input/Output Parameters:   
*       graninfo        Granule level information needed by inverse geolocation
*
*!Return Value:
*       MODIS_E_SDST_IGEO_BAD_DATA  If spacecraft position is invalid
*       PGS_S_SUCCESS               Otherwise
*
*!Global Variables:
*       None
*
*!Called by:
*       SDST_IGEO_get_graninfo()
*
*!Routines called:
*       PGS_CSC_Norm
*       PGS_CSC_crossProduct
*       PGS_CSC_dotProduct
*
*
*!Revision History:
*See top of file.
*
*
*!Requirements:
*       CCR-468
*
*
*!Team-unique Header:
*       This software is developed by the MODIS Science Data Support
*       Team for the National Aeronautics and Space Administration,
*       Goddard Space Flight Center, under contract NAS5-32373.
*
*
*!References and Credits:
*       HDF portions of this code were developed at the National Center
*       for Supercomputing Applications at the University of Illinois at
*       Urbana-Champaign
*
*
!END ***************************************************************************
*/
{
   int       gran,i;
   double    norm;
   double    radius;
   char      msgbuf[128];

   radius = PGS_CSC_Norm((PGSt_double *)scan_info[0]->sc_position);
   if(radius <=0){
      sprintf(msgbuf, " %s scan %ld has a spacecraft position of 0.0.", 
                 graninfo->filename, (long)scan_info[0]->iscan);
      modsmf(MODIS_E_SDST_IGEO_BAD_DATA, msgbuf, __FILE__ ", SDST_IGEO_calc_gran_coords");
      return MODIS_E_SDST_IGEO_BAD_DATA;
   }


   for(i=0; i<3; i++){
      graninfo->T_ecr2gran[0][i] = scan_info[0]->sc_position[i]/radius;
   }
   
   if(scan_info[1] == NULL){
      /* The granule has only one useable scan, so we cannot calibrate the scan
       * estimation, but we can locate positions that happen to be in that scan.
       * The following line is sufficient to ensure that SDST_IGEO_estimate_scan() will
       * always return gran_info.first_scan:
     */
      scan_info[1] = scan_info[0];
   }


   PGS_CSC_crossProduct((PGSt_double *)scan_info[0]->sc_position, 
                        (PGSt_double *)scan_info[1]->sc_position,graninfo->T_ecr2gran[2]);
   norm = PGS_CSC_Norm(graninfo->T_ecr2gran[2]);
   if(norm > 0){
       /* norm will be 0 for 1-scan granules. */
      for(i=0; i<3; i++){
         graninfo->T_ecr2gran[2][i] /= norm;
      }
   }

   PGS_CSC_crossProduct(graninfo->T_ecr2gran[2],
                         graninfo->T_ecr2gran[0], graninfo->T_ecr2gran[1]);
   /* T_ecr2gran[1] doesn't need to be normalized, because by construction, it is
    * already a unit vectors, unless there is only one usable scan in the granule,
    * in which case it will be 0.
  */

   for(gran= 0; gran< 3; gran++){
      graninfo->mirror_axis[gran] =
          PGS_CSC_dotProduct(graninfo->T_ecr2gran[gran], (PGSt_double *)scan_info[0]->T_ecr2scan[2], 3);
      /* T_ecr2scan[2] is the mirror axis in ECR coordinates. */
 
   }


   graninfo->mirror_perp = radius * graninfo->mirror_axis[0];

   /* This derived value is technically redundant, but saves time. */
   graninfo->mirror_trans2 =graninfo->mirror_axis[0]*graninfo->mirror_axis[0]
                            + graninfo->mirror_axis[1]*graninfo->mirror_axis[1];

   return PGS_S_SUCCESS;

}






PGSt_SMF_status SDST_IGEO_get_graninfo(
                MODFILE                 *geo_file,
                graninfo_struct         *graninfo)
/*
*!C******************************************************************************
*!Description:
*       Subroutine of the inverse geoloation routine which loads and calculates
*       the needed granule level information from the geolocation file
*       identified by geo_file.
*
*
*!Input Parameters:
*       geo_file         M-API file handle for the geolocation file.
*
*!Output Parameters:
*       graninfo        Granule-level information needed by inverse geolocation.
*
*
*
*Return Value:                       status
*        MODIS_E_SDST_IGEO_BAD_ARG   The geolocation file's name is missing
*        MODIS_E_SDST_IGEO_BAD_DATA* The geofile contains corrupt data.
*        MODIS_E_SDST_IGEO_INTERNAL  Fatal internal error in self or subroutines
*        MODIS_E_SDST_IGEO_MEM*      Insuffient memory.
*        MODIS_E_SDST_IGEO_READ*     I/O Error while reading geolocation file
*        MODIS_W_SDST_IGEO_INTERNAL* No usable scans, due to non-fatal internal
*                                    errors.
*        MODIS_N_SDST_IGEO_NOTFOUND       Couldn't find all needed data.
*        PGS_S_SUCCESS               Otherwise
** - status not generated in this function, but passed on from sub-routines.
*
*
*
*Global variables:       None
*
*Called by:
*        SDST_IGEO_estimate_scan_number()
*
*Rutines called:
*        SDST_IGEO_calibrate_gran_par()
*        SDST_IGEO_calc_gran_coords()
*        SDST_IGEO_get_scan()
*        SDST_IGEO_load_gran()
*
*Requirements:
*         CCR 468
*
*!Revision History:
*See top of file.
*
*
*!Team-unique Header:
*        This software is developed by the MODIS Science Data Support
*        Team for the National Aeronautics and Space Administration,
*        Goddard Space Flight Center, under contract NAS5-32373.
*
*!END **************************************************************************
*/

{
    PGSt_SMF_status 	retval, status=PGS_S_SUCCESS;    
    scan_info_struct *  scan_info[2]={NULL};
    int                 last_scan;


    if(graninfo == NULL){
       return MODIS_E_SDST_IGEO_INTERNAL;
    }

    status = SDST_IGEO_load_gran(geo_file, graninfo);
    if(status != PGS_S_SUCCESS){
       return status;
    }


    /* This clears out the data stored from previous calls. */
    status = SDST_IGEO_get_scan(NULL,0,NULL);
    if(status != PGS_S_SUCCESS){
       return MODIS_E_SDST_IGEO_INTERNAL;
    }

    /* From here on in, the 'status' variable records the most serious problem
     * encountered. If this subroutine terminates early, it should return 'status',
     * even if that problem was not the direct cause of the termination. However,
     * if this function completes properly, it should return PGS_S_SUCCESS,
     * regardless of the value of 'status'.
     */

    /* Locate the first usable scan in the granule. */
    for(graninfo->first_scan = 0; graninfo->first_scan <graninfo->scans; graninfo->first_scan++){
       if(graninfo->quality[graninfo->first_scan] == 0){
          retval = SDST_IGEO_get_scan(geo_file, graninfo->first_scan, &scan_info[0]);
          if(retval > MODIS_W_SDST_IGEO_INTERNAL){
             return retval;
          }else if(retval == PGS_S_SUCCESS) {
             break;
          }else if(retval > status) {
             status = retval;
          }
       }
    }


    /* Locate the last usable scan in the granule. */
    for(last_scan = graninfo->scans-1; last_scan > graninfo->first_scan; last_scan--){
       if(graninfo->quality[last_scan] == 0){
          retval = SDST_IGEO_get_scan(geo_file, last_scan, &scan_info[1]);

          if(retval > MODIS_W_SDST_IGEO_INTERNAL){
             return retval;
          }else if(retval == PGS_S_SUCCESS) {
             break;
          }else if(retval > status) {
             status = retval;
          }

       }
    }


    if(scan_info[0] == NULL){
       /* A granule with no useable scans is quite possible, and is not an
        * error condition in itself. However, you can't use it for inverse
        * geolocation!
        */
       if(status < MODIS_N_SDST_IGEO_NOTFOUND)
          status = MODIS_N_SDST_IGEO_NOTFOUND;
       return status;
    }

    retval = SDST_IGEO_calc_gran_coords(scan_info, graninfo);
    if(retval != PGS_S_SUCCESS) {
       if(retval > status) status = retval;
       return status;
    }


    retval = SDST_IGEO_calibrate_gran_par(scan_info, graninfo);
    if(retval != PGS_S_SUCCESS) {
       if(retval > status) status = retval;
       return status;
    }



    /* Whatever problems did occur, didn't stop us, so we can finally */

    return PGS_S_SUCCESS;
}
