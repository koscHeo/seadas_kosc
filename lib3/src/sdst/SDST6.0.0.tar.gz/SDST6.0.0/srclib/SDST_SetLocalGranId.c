#include "PGS_MET.h"
#include "PGS_MODIS_39604.h"
#include "mapi.h"
#include "hdf.h"
#include <string.h>
#include <time.h>
#include "smfio.h" 
#include "SDST_GetSetPSA.h"
#include "SDST_SetLGranId.h" 

PGSt_SMF_status SDST_SetLocalGranId(
	const enum PROD_TYPE prod_type,
	PGSt_MET_all_handles mdHandles)
/******************************************************************************
 * !C
 *
 * !Purpose:
 *	 To create a unique filename from ECS metadata and write it to
 *       LOCALGRANULEID.	
 *
 * !Description:
 *       Function SDST_SetLocalGranId is part of a larger software system
 *       called the SDST utility toolkit abbreviated SDST_TK. SDST_TK consists
 *       of in-house developed utility routines which the MODIS Science Team
 *       can link to MODIS production software. 
 *
 *       This function reads in the following metadata from the ECS Inventory
 *	 metadata mdHandle:
 *               SHORTNAME
 *               RANGEBEGINNINGDATE
 *               RANGEBEGINNINGTIME
 *               VERSIONID
 *
 *       For L2G and L3 use only, Product Specific Attributes:
 *               HORIZONTALTILENUMBER
 *               VERTICALTILENUMBER
 *
 *	 For oceans only:
 *               StartDataDay
 *
 *       and writes out to the ECS Inventory mdHandle 
 *               LOCALGRANULEID
 *
 *       This routine will generate a unique product filename based on the
 *       product type and the metadata retrieved from memory.  The ECS 
 *	 metadata above must therefore be set using PGS_MET_SetAttr() prior
 *	 to calling SDST_SetLocalGranId.  The filename is created and set to 
 *       LOCALINPUTGRANULEID metadata.  
 *
 *
 *     Product File Names
 *	 Within the naming conventions, these names are to be included in the
 *       metadata under LocalGranuleID =.  
 *
 *     If prod_type is set to  any of these (L1A, L1B, L2, GEO),
 *       LOCALGRANULEID will be set to the following file format. 
 *      
 *     Level-1A, Level-1B, and Level-2 Product Naming Convention
 *
 *	 ESDT.Ayyyyddd.hhmm.vvv.yyyydddhhmmss.hdf where:
 *
 *	 ESDT represents the ESDT shortname of the product (eight characters), 
 *       A originally represented the EOS-AM1 satellite. Now it is meaningless.
 *       yyyyddd represents the four-digit year followed by the day number (1-366)
 *       within the year, for the start of the granule, 
 *       hhmm represents the time of day applying to the start of the granule,
 *       in hours and minutes,
 *       vvv represents a three-digit version number for the product,
 *       yyyydddhhmmss represents the four digit year, day number (1-366) within
 *            the year, hours, minutes, and seconds of a time at which the granule
 *            was processed. These times should be UTC times, not local time zone
 *            values.
 *       hdf represents the fact that this is an hdf file.
 *
 *	 File Naming L2 example - the third version of the L2 cloud mask
 *         product for January 1, 1999 at 08:30, generated on January 1, 1999 at
 *         9:00:20 am would be encoded as follows:
 *         MOD35_L2.A1999001.0830.003.1999001090020.hdf.
 *
 *	 File Naming L1B example - the second version of the L1B radiance product
 *         for January 1, 1999 at 10:15, generated on January 1, 1999 at 
 *         9:00:20am would be encoded as follows:
 *         MOD02.A1999001.1015.002.1999001090020.hdf
 *
 *     Level-2G and Level-3 Product Naming Convention (Land/Tile)
 *
 *     If prod_type is set to LAND or L2G, LOCALGRANULEID will be set to the 
 *         following file format.
 *
 *	 ESDT.Ayyyyddd.h<hnum>v<vnum>.vvv.yyyydddhhmmss.hdf where:
 *
 *	 ESDT represents the ESDT shortname of the product, 
 *	 A originally represented the EOS-AM1 satellite. Now it is meaningless. 
 *       yyyyddd represents the four-digit year followed by day number (1-366)
 *          within the year, for the the start of the granule within the file, 
 *       hnum is the two-digit tile number in the horizontal direction for the
 *          global grid, and is zero-based (Note:  Used for Land files only). 
 *       vnum is the two-digit tile number in the vertical direction for the
 *          global grid, and is zero-based (Note:  Used for Land files only). 
 *       vvv represents a three-digit version number for the product.
 *       yyyydddhhmmss represents the four digit year, day number (1-366)
 *          within the year, hours, minutes, and seconds of a time at which the
 *          granule was processed. These times should be UTC times, not local
 *          time zone values.
 *	 hdf represents the fact that this is an hdf file.
 *
 *	 File Naming Land example - the first version of the 16-day L3
 *         Bi-directional Reflectance Distribution Function product for December
 *         31, 1998, at the 5th horizontal tile and 8th vertical tile, generated
 *         on January 1, 1999 at 9:00:20 am would be encoded as follows:
 *         MOD43A2.A1998365.h05v08.001.1999001090020.hdf
 *
 *     If prod_type is set to ATMOS, localgranuleid will be set to the following
 *         file format.
 *
 *	 ESDT.Ayyyyddd.vvv.yyyydddhhmmss.hdf 
 *
 *         where the fields are the same for LAND.
 *
 *     If prod_type is set to OCEANS, LOCALGRANULEID will be set to the 
 *         following file format.
 *
 *	 ESDT.Ayyyyddd.hhmm.DDyyyyddd vvv.yyyydddhhmmss.hdf
 *          (L3 space binner- msbin)
 *	 ESDT.ADDyyyyddd.vvv.yyyydddhhmmss.hdf (L3 time binner- mtbin) where:
 *
 *       ESDT represents the ESDT shortname of the product, 
 *	 A originally represented the EOS-AM1 satellite. Now it is meaningless. 
 *	 yyyyddd represents the four-digit year followed by day number (1-366)
 *         within the year, for the the start of the granule within the file, 
 *       hhmm represents the time of day applying to the start of the granule,
 *          in hours and minutes,
 *       DDyyyyddd represents the StartDataDay (four-digit year followed by the
 *          day number (1-366) within the year)
 *       vvv represents a three-digit version number for the product,
 *       yyyydddhhmmss represents the four digit year, day number (1-366) within
 *          the year, hours, minutes, and seconds of a time at which the granule
 *          was processed. These times should be UTC times, not local time zone
 *          values.
 *       hdf represents the fact that this is an hdf file.
 *
 *	 Oceans example - the fourth version of the L3 ocean spacebinning product
 *       generated on January 4, 1999 at 9:00:20 am would be encoded as follows:
 *       MOD28BD1.A1999003.0130.DD1999002.004.1999004090020.hdf
 *
 *       Oceans example - the fifth version of the L3 ocean time binning product
 *       for data collected for dataday January 2, 1999 generated on January 4,
 *       1999 at 9:00:20 am would be encoded as follows:
 *         MOD28AD1.ADD1999002.005.1999004090020.hdf
 *
 *  !Input Parameters:
 *       prod_type: one of the enumerated types of PROD_TYPE found in
 *		SDST_SetLGranId.h (values: L1A, L1B, GEO, L2, L2G, ATMOS,
 *               OCEANS, LAND)
 *       mdHandles identifier used to access metadata groups in the MCF,
 *		initialized by PGS_MET_Init.
 *
 *  !Output Parameters:
 *       none
 *
 *  !Return Value:
 *       MODIS_S_SDST_SUCCESS if all metadata is successfully retrieved and 
 *              the LOCALGRANULEID is set. 
 *       MODIS_W_SDST_VERSIONID_BAD if PGEVERSION can not be retrieved.
 *       MODIS_W_SDST_TILECOORD_BAD if HORIZONTALTILENUMBER, VERTICALTILENUMBER
 *              or StartDataDay cannot be retrieved.
 *       MODIS_E_SDST_BAD_DATE_FORMAT if RANGEBEGINNINGDATE is in wrong format.
 *       MODIS_E_SDST_BAD_ECS_DATA if SHORTNAME, RANGEBEGINNINGDATE, or 
 *		RANGEBEGINNINGTIME can not be retrieved.
 *       MODIS_E_SDST_BAD_MDHANDLES if mdhandles is invalid. 
 *       MODIS_E_SDST_BAD_PROD_TYPE if prod_type is invalid.
 *       MODIS_E_SDST_BAD_TIME_FORMAT if RANGEBEGINNINGTIME is in wrong format. 
 *       MODIS_E_SDST_LOCALGRANULEID if LOCALGRANULEID can not be set.
 *       These macros are in PGS_MODIS_39604.h.
 *
 * Externally Defined:
 *      DD_DEFLT				SDST_SetGranId.h
 *	INVENTORY_METADATA			mapi.h
 *      MAX_BUFF_SIZE				SDST_SetGranId.h
 *      MCORE_SHORT_NAME			mapi.h
 *      MCORE_RANGE_BEG_DATE			mapi.h
 *      MCORE_RANGE_BEG_TIME			mapi.h
 *      MCORE_VERSIONID				mapi.h
 *      MODIS_E_SDST_BAD_DATE_FORMAT		PGS_MODIS_39604.h
 *      MODIS_E_SDST_BAD_ECS_DATA		PGS_MODIS_39604.h
 *      MODIS_E_SDST_BAD_MDHANDLES		PGS_MODIS_39604.h
 *      MODIS_E_SDST_BAD_PROD_TYPE		PGS_MODIS_39604.h
 *      MODIS_E_SDST_BAD_TIME_FORMAT		PGS_MODIS_39604.h
 *      MODIS_E_SDST_LOCALGRANULEID		PGS_MODIS_39604.h
 *      MODIS_S_SDST_SUCCESS			PGS_MODIS_39604.h
 *      MODIS_W_SDST_VERSIONID_BAD		PGS_MODIS_39604.h
 *      MODIS_W_SDST_TILECOORD_BAD		PGS_MODIS_39604.h
 *      MPROD_HORIZ_TILE_NUM			mapi.h
 *      MPROD_VERT_TILE_NUM			mapi.h
 *      TILE_DEFLT				SDST_SetGranId.h
 *	PGS_S_SUCCESS				PGS_SMF.h
 *      PROC_TIME_SIZE				SDST_SetGranId.h
 *      SAT_MODE				SDST_SetGranId.h
 *      STARTDATADAY				SDST_SetGranId.h
 *      VERSIONID_DEFLT				SDST_SetGranId.h
 *
 *  Called by:
 *	csdst_slgi()	C/Fortran interface function.
 *	User-written C routines.
 *
 *  !Routines Called:
 *       PGS_MET_GetSetAttr			PGS_MET.h
 *       PGS_MET_SetAttr			PGS_MET.h
 *       modsmf					smfio.h
 *       SDST_GetSetPSA				SDST_GetSetPSA.h
 *
 *  !Revision History:
 *       $Log: SDST_SetLocalGranId.c,v $
 *       Revision 6.1  2009/06/30 15:53:02  kuyper
 *       Changed to resolve Bug 2468 by checking for ReprocessingActual ECS
 *         metadata.If that object exists and has a value of "Near Real Time",
 *         the LocalGranuleID will end with ".NRT.hdf" rather than ".hdf".
 *
 *	 James Kuyper		James.R.Kuyper@nasa.gov
 *
 *       Revision 4.3  2003/01/29 23:37:25  kuyper
 *       Corrected datatype of iver, resolving ddts report MODur00004.
 *
 *       Revision 4.2  2002/11/27 23:42:01  kuyper
 *       Corrected comment about space-biner file naming conventions.
 *
 *       Revision 4.1  2002/11/27 17:23:43  kuyper
 *       Changed to call mktime using a fixed hour of 12, to avoid daylight savings
 *         time issues.
 *
 *       Revision 3.1  2002/03/22 22:06:54  kuyper
 *       Corrected setup for call to mktime().
 *
 *       Revision 2.6  2001/12/05 15:59:47  pliu
 *       Added return values to prolog.
 *
 *       Revision 2.5  2001/11/15 17:20:21  pliu
 *       Changed VERSION_DEFLT to VERSIONID_DEFLT.
 *
 *       Revision 2.4  2001/11/15 15:53:45  pliu
 *       Fixed the bug of treating VERSIONID as string. It should be integer.
 *
 *       Revision 2.3  2001/07/12 14:20:46  pliu
 *       Changed to use VersionID instead of PGEversion to obtain version information.
 *
 * Revision 2.2  1999/09/28  00:03:42  solanki
 * Cleaned up and working on all platforms.
 *
 * Revision 1.1  1999/09/03  21:48:51  solanki
 * Initial revision
 *
 * Revision 2.1  1999/05/11  17:25:57  jjb
 * Removed defects found in code walkthrough.
 *
 * Revision 2.0  1999/04/27  20:57:25  jjb
 * Corrected Land Level-3 functionality to retrieve
 * tile numbers from PSA's.
 * Added Oceans Level-3 functionality.
 *
 * Revision 1.2  1999/03/18  17:09:43  solanki
 * Added #include smfio.h.
 *
 * Revision 1.1  1999/02/24  15:03:08  solanki
 * Initial revision
 *
 *  !Team-unique Header:
 *       This software is developed by the MODIS Science Data Support Team for
 *       the National Aeronautics and Space Goddard Space Flight Center, under
 *       contract NAS5-32373.
 *
 *  !Design Notes:
 *
 *   There are multiple exits from this routine based on the return status of
 *   the PGS Toolkit routines when retrieving the metadata.
 *   
 *  !END
 ******************************************************************************/
{

    char localgranuleid[MAX_BUFF_SIZE] = "";  	/* output string */
    int retval = MODIS_S_SDST_SUCCESS;
    int  num_retvals;				/* scanf return count */
    PGSt_integer iver;			        /* integer versionID  */
    char proc_time[PROC_TIME_SIZE];	        
    char *buff;
    struct tm gran_time = {0};       		/* for storing time  */
    int year, month, day, hour, min, yearday;   /* for range beginning date and time*/
    int i;
    enum ecs_index{NAME, DATE, TIME, REPROC};	/* ECS_metadata indices */
    enum psa_index{HORIZ, VERT, BOBDAY};	/* PSA_metadata indices */
    time_t t;
    const char *extension = "NRT.hdf";		/* Ending of LGID */

    static struct {				/* ECS metadata retrieval */
       char * attrNameStr;			/* name/data pairs	*/
       char   data[MAX_BUFF_SIZE];
       } ECS_metadata[] = {
         {MCORE_SHORT_NAME, ""},
         {MCORE_RANGE_BEG_DATE, ""},
         {MCORE_RANGE_BEG_TIME, ""},
	 {MCORE_ACTUALLY_REDONE, ""}
    };

    static struct {				/* PSA retrieval	*/
       char * attrNameStr;			/* name/data pairs	*/
       char   data[MAX_BUFF_SIZE];
       } PSA_metadata[] = {
         {MPROD_HORIZ_TILE_NUM, "" },
         {MPROD_VERT_TILE_NUM, ""},
         {STARTDATADAY, ""},
    };

    /* Check if mdHandles is invalid  */
    if ( mdHandles == NULL){
      modsmf(MODIS_E_SDST_BAD_MDHANDLES,"",
	     "SDST_SetLocalGranId.c, SDST_SetLGranuleId");
      return MODIS_E_SDST_BAD_MDHANDLES;
    }
    
    
    /* Read the following inventory metadata:           
          SHORTNAME                                
          RANGEBEGINNINGDATE                       
          RANGEBEGINNINGTIME                       
       If error retrieving metadata return:                
          MODIS_E_SDST_BAD_ECS_DATA                
    */ 

    for (i = 0; i < (int)(sizeof(ECS_metadata)/sizeof(ECS_metadata[0])); i++){
      buff = ECS_metadata[i].data;
      if (PGS_MET_GetSetAttr(mdHandles[INVENTORY_METADATA],
			     ECS_metadata[i].attrNameStr, &buff)
	  != PGS_S_SUCCESS && i != REPROC)
      {	/* ReprocessingActual is not mandatory:  MOD03CP and MYD03CP lack it. */
	  modsmf(MODIS_E_SDST_BAD_ECS_DATA, ECS_metadata[i].attrNameStr,
	       "SDST_SetLocalGranId.c, PGS_MET_GetSetAttr");

	  return MODIS_E_SDST_BAD_ECS_DATA;
      }
    }

    /* Check format of "RANGEBEGINNINGDATE" (expected format is YYYY-MM-DD.). */
    
    num_retvals = sscanf(ECS_metadata[DATE].data, "%4d-%2d-%2d",
			 &year, &month, &day);
    if ( num_retvals != 3){
      modsmf(MODIS_E_SDST_BAD_DATE_FORMAT, ECS_metadata[DATE].data, 
             "SDST_SetLocalGranId.c, sscanf");
      return MODIS_E_SDST_BAD_DATE_FORMAT;
    }
    

    /* Check format of "RANGEBEGINNINGTIME"                                   *
     * (expected format is HH:MM:SS.SSSSSS)                                   */
    num_retvals = sscanf(ECS_metadata[TIME].data, "%2d:%2d", &hour, &min);
    if ( num_retvals != 2){
      modsmf(MODIS_E_SDST_BAD_TIME_FORMAT, ECS_metadata[TIME].data, 
             "SDST_SetLocalGranId.c, sscanf");
      return MODIS_E_SDST_BAD_TIME_FORMAT;
    }
    
    /* Fill in tm structure, and convert the granule beginning time 
       to Julian date */
    gran_time.tm_year = year - 1900;
    gran_time.tm_mon = month - 1;
    gran_time.tm_mday = day;
    gran_time.tm_hour = 12;	/* To avoid daylight savings time issues. */
    t = mktime(&gran_time);
    yearday = gran_time.tm_yday + 1;
    
    /* Get current processing time and date.  Convert processing time to UTC
       time and Julian date if necessary.  (format should be yyyydddhhmmss.)
       Append converted processing time and date to localgranuleid.
    */
    
    t = time(NULL);
    gran_time = *(gmtime(&t));
    strftime(proc_time, 80, "%Y%j%H%M%S", &gran_time);
    
    /* Append the value contained in "VERSIONID",            *
     * padding to three characters, to localinputgranuleid.   */
    
    if (PGS_MET_GetSetAttr(mdHandles[INVENTORY_METADATA], MCORE_VERSIONID,
      &iver) != PGS_S_SUCCESS ||
      iver < (PGSt_integer)0 || iver > (PGSt_integer)999)
    {
      modsmf(MODIS_W_SDST_VERSIONID_BAD, "",
	  "SDST_SetLocalGranId.c, PGS_MET_GetSetAttr");
      retval = MODIS_W_SDST_VERSIONID_BAD;
      iver = VERSIONID_DEFLT; /* set iver to default versionid: 0 */
    }
    if(strcmp(ECS_metadata[REPROC].data, "Near Real Time"))
	/* Skip the "NRT" on the extension.	*/
	extension += 4;

    /* starting to setup localgranuleid based on prod_type */
    switch (prod_type) {
    case L1A:
    case GEO:
    case L1B:
    case L2:
      
      /* Append SHORTNAME and 'A' to localgranuleid.  */
      /*  ESDT.Ayyyyddd.hhmm.vvv.yyyydddhhmmss.hdf */
      sprintf(localgranuleid,"%.8s.%c%04d%03d.%02d%02d.%03ld.%.13s.%3s", 
	      ECS_metadata[NAME].data,SAT_MODE, year, yearday, hour, min, 
	      (long)iver, proc_time, extension);
      break;
      
    case ATMOS:
      /* Level-3 atmosphere format: */
      /*  ESDT.Ayyyyddd.vvv.yyyydddhhmmss.hdf */
      sprintf(localgranuleid,"%.8s.%c%04d%03d.%03ld.%.13s.%3s",
	      ECS_metadata[NAME].data,
	      SAT_MODE, year, yearday, (long)iver,  proc_time, extension);
      break;
      
    case L2G:
    case LAND:
      
      /* Convert values which correspond to HORIZONTALTILEID and
       * VERTICALTILEID  to the following string format: [h<hnum>v<vnum>]. 
       * Append  with "." to localinputgranuleid.                         
       */
      
      for (i = (int)HORIZ; i <= (int)VERT; i++){
	buff = PSA_metadata[i].data;
	if (SDST_GetSetPSA(mdHandles[INVENTORY_METADATA],
			   PSA_metadata[i].attrNameStr, &buff) 
	    != PGS_S_SUCCESS){
	  /* call SDP SMF function to report error  */
	  modsmf(MODIS_W_SDST_TILECOORD_BAD, PSA_metadata[i].attrNameStr,
		 "SDST_SetLGranuleId.c, SDST_GetSetPSA");
	  retval = MODIS_W_SDST_TILECOORD_BAD;
	  strncpy( PSA_metadata[i].data, TILE_DEFLT,
	      sizeof(PSA_metadata[i].data));
	}
      }
      
      /*  ESDT.Ayyyyddd.hnumvnum.vvv.yyyydddhhmmss.hdf */
      sprintf(localgranuleid,"%.8s.%c%04d%03d.h%.2sv%.2s.%03ld.%.13s.%3s",
	      ECS_metadata[NAME].data,
	      SAT_MODE, year, yearday, PSA_metadata[HORIZ].data,
	      PSA_metadata[VERT].data, (long)iver, proc_time,  extension);
      break;

    case OCEANS:
      /* Insert the StartDataDay (yyyyddd) after the 'DD' field */
      buff = PSA_metadata[BOBDAY].data;
      if (SDST_GetSetPSA(mdHandles[INVENTORY_METADATA],
			 PSA_metadata[BOBDAY].attrNameStr, 
			 &buff) 
	  != PGS_S_SUCCESS){
	/* call SDP SMF function to report error  */
	modsmf(MODIS_W_SDST_TILECOORD_BAD, PSA_metadata[BOBDAY].attrNameStr,
	       "SDST_SetLGranuleId.c, SDST_GetSetPSA");
	retval = MODIS_W_SDST_TILECOORD_BAD;
	strncpy( PSA_metadata[BOBDAY].data, DD_DEFLT, 
		 sizeof(PSA_metadata[BOBDAY].data));
      }
      if (ECS_metadata[NAME].data[5] == 'B') 
	/* Oceans granules from msbin contain B as the 6th character 
	   in their ESDTs */
	
	/* format for L3 space binned granule from msbin */
	/*  ESDT.Ayyyyddd.hhmm.DDyyyyddd.vvv.yyyydddhhmmss.hdf */
	sprintf(localgranuleid,
	    "%.8s.%c%04d%03d.%02d%02d.DD%.7s.%03ld.%.13s.%3s",
	    ECS_metadata[NAME].data, SAT_MODE, year, yearday, hour, min,
	    PSA_metadata[BOBDAY].data, (long)iver, proc_time,  extension);
      else
	/*  ESDT.ADDyyyyddd.vvv.yyyydddhhmmss.hdf */
	sprintf(localgranuleid,"%.8s.%cDD%.7s.%03ld.%.13s.%3s",
		ECS_metadata[NAME].data, SAT_MODE, PSA_metadata[BOBDAY].data,
		(long)iver, proc_time,  extension);
      break;
      
      /* prod_type is not a valid type.   */
    default:
      modsmf(MODIS_E_SDST_BAD_PROD_TYPE, "",
	     "SDST_SetLocalGranId.c, SDST_SetLocalGranId");
      return MODIS_E_SDST_BAD_PROD_TYPE;
    }

    buff = localgranuleid;
    if (PGS_MET_SetAttr(mdHandles[INVENTORY_METADATA], MCORE_LOCALGRANULEID,
			&buff) != PGS_S_SUCCESS){
      /* call SDP SMF function to report error  */
      modsmf(MODIS_E_SDST_LOCALGRANULEID, MCORE_LOCALGRANULEID,
             "SDST_SetLocalGranId.c, PGS_MET_SetAttr");
      return MODIS_E_SDST_LOCALGRANULEID;
    }
    
    return retval;
}
