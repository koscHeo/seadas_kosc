/*********************** filename modisL2reader.c ***********************/

#include  "float.h"
#include  "mapic.h"
#include  "mapi.h"
#include  <math.h>
#include "netcdf.h"


int modisL2reader (
	MODFILE *file,
	const int control_flag[],
	const char *groupname,
	const char *arrayname,
	const long int start[],
	const long int dimsizes[],
	long Fill_Value,
	double *value
)
/*
!C****************************************************************************
* 
*!Description:	Function modisL2reader retrieves a named array and converts
*		the array data to geophysical data.
*
*!Input parameters:
*
*	file	
*		IN:	Address of MODFILE structure that is used to reference
*			the MODIS HDF file containing the SDS (array).
*
*	control_flag
*		IN:	Control flag indicating the operation being done.
*
*			If control_flag[0] equals zero : 
*			add offset is subtracted from the retrieved array.
*
*			If control_flag[0] does not equal zero : 
*			add_offset is added to the retrieved array.
*
*			If control_flag[1] equals zero : 
*			retrieved array is divided by the scale_factor.
*
*			If control_flag[1] does not equal zero : 
*			retrieved array is multiplied by the scale_factor. 
*				
*    groupname
*		IN:	ASCII string name of the data group containing the array.
*
*    arrayname	
*		IN:	ASCII string name of the array.  Provided macros for 
*			accepted MODIS HDF file array names are listed in 
*			Appendix A, M-API Supplied Constants.
*
*    start
*		IN:	Array structure locations to begin reading data from the
*			array struct.  Must have the same number of elements as
*			the target array has dimensions.
*
*    Dimsizes
*		IN:	Array describing the size of the array being retrieved
*			from the array structure.  Dimsizes must have the same
*	 		number of elements as the target array has dimensions. 
* 			The product of the array dimensions must be equal to or
*			greater than the number of elements of value.
*
*    Fill_Value 
*		IN:     FillValue of datatype long int.  This FillValue will be 
*			cast to double when written to the output double array.
*
*!Output parameters:		
*
*     value
*		OUT:	Address of output array with data type double. This 
*			means users must define this argument to be of the same 
*			type before calling this function.
*
*!Returns:	MAPIOK if successful, or MFAIL if an error occurs.
*
*!Called By:
*               This function is called by programs that want to read MODIS
*               level 2 data.
*
*!Routines Called:
*	        getMODISardims
*		MODISsizeof	
*               getMODISarray	
*      	        getMODISarinfo	
*
*!External references:
*		DATATYPELENMAX			(mapic.h)
*               I8, I16, I32, R32, R64          (mapi.h)
*		MAPIOK				(mapi.h)
*		MAPIERR				(mapic.h)
*		MAPIWARN			(mapic.h)
*               MAX_VAR_DIMS                    (netcdf.h)
*		FILL_BYTE			(netcdf.h)
*		FILL_SHORT			(netcdf.h)
*		FILL_LONG			(netcdf.h)
*		FILL_FLOAT			(netcdf.h)
*		FILL_DOUBLE			(netcdf.h)
*		MFAIL				(mapi.h)
*               MFILL_VALUE			(mapi.h)
*		MODFILE                         (mapic.h)
*		MOFFSET				(mapi.h)
*	        MSLOPE				(mapi.h)
*               PGS_SMF_MAX_MSGBUF_SIZE         (mapic.h)  ----  PGS_SMF.h
*
*
*!Revision History:
* $Log: modisL2reader.c,v $
* Revision 5.1  2009/06/27 19:29:43  kuyper
* Removed code that made the unportable assumption that the expansion of NULL
*   is an expression of integer type.
* Improved const safety.
*
* James Kuyper		James.R.Kuyper@nasa.gov
*
* Revision 1.6  2001/08/29 19:37:25  pliu
* Added log clause.
* Changed n_elements, byte_of_element from int to long int.
*
*
*
*               Qi Huang     1997/05/30
*		Version 2.3
*               Original development
*                
*               Arvind Solanki  1998/03/10
*               Version 2.4
*               Modified to use macros where defined and add Called by and
*               Routines called in prolog,changed multiple ifs to else ifs.
*               Added control flag.
*	
*		Jayshree Murthy 1998/09/15
*		Changed FillValue from output to input
*		Added default values for scale_factor, 
*		add_offset and FillValue
*
*!Team-unique header:
*               This software is developed by the MODIS Science Data Support
*               Team for the National Aeronautics and Space Administration, 
*               Goddard Space Flight Center, under contract NAS5-32373.
*
*!References and Credits:
*               HDF portions of this code were developed at the National Center
*               for Supercomputing Applications at the University of Illinois at 
*               Urbana-Champaign.
*
*!Design Notes
*               This routine assumes that the HDF file accessed contains the 
*               values for add_offset and scale factor as defined by the HDF
*               manual.  If these values are not provided in the HDF file,
*		a default value of zero for the add_offset and 1 for the
*		scale_factor will be used.
*
!END***************************************************************************
*/


{
  char          buff[PGS_SMF_MAX_MSGBUF_SIZE];
  char          *funcname = "modisL2reader";
  long int      n_elements = 1;
  float64       scale_factor, add_offset;
  float64       fillvalue;
  float64       *FillValue = &fillvalue;
  long int      attr_n_elements = 1;
  long int      rank = MAX_VAR_DIMS;
  char          datatype[DATATYPELENMAX];
  long int      loc_dimsizes[MAX_VAR_DIMS];
  void          *temp_value;
  long int           byte_of_element = 0;
  char          attr_datatype[DATATYPELENMAX] = R64;
  int           i;
  int           status = MAPIOK;
 

  
  
  /* Retrieve datatype and rank of the array */
  if (getMODISardims(file, (char*)arrayname, (char*)groupname,datatype, &rank,
      loc_dimsizes) != MAPIOK)
  {
      sprintf(buff,"ERROR:modisL2reader detected MFAIL from M-API procedure\n"
                    "\t getMODISardims while retrieving datatype and rank \n"
                    "\t of array %s.\n",arrayname);
      
      MAPIERR(buff,funcname);
      return(MFAIL);
  }



  for (i=0; i<rank; i++)
    n_elements = n_elements * dimsizes[i];
 
  
  if ((byte_of_element = MODISsizeof(datatype)) == MFAIL)
   
  {
    sprintf(buff,"ERROR: modisL2reader finds incorrect datatype input %.*s while\n"
                     "\t converting array to geophysical data.\n", MAX_NC_NAME,datatype);
    MAPIERR(buff,funcname);
    return(MFAIL);
  }



  /* allocate memory for array */
  if ((temp_value = (void *)malloc(byte_of_element*n_elements)) == NULL)
  {
      sprintf(buff,"ERROR: modisL2reader fails while allocating memory for\n"
                       "\t buffer temp_value.\n");
      MAPIERR(buff,funcname);
      return(MFAIL);
  }


  /* Retrieve data of array */
  if (getMODISarray(file, (char*)arrayname, (char*)groupname, (long*)start,
      (long*)dimsizes, temp_value) != MAPIOK)
  {
      sprintf(buff,"ERROR: modisL2reader detected MFAIL from M-API procedure\n"
                   "\t getMODISarray while retrieving data of array %.*s.\n",
                   MAX_NC_NAME,arrayname);
      MAPIERR(buff,funcname);
      free(temp_value);
      return(MFAIL);
  }


  /* Retrieve scale_factor */
  if (getMODISarinfo(file, (char*)arrayname, (char*)groupname, MSLOPE,
      attr_datatype, &attr_n_elements, &scale_factor) != MAPIOK)
  {
  	if (attr_n_elements == 0)
	{
          sprintf(buff,"ERROR: modisL2reader detected MFAIL from M-API procedure\n"
                          "\t getMODISarinfo while retrieving attribute %.*s from\n"
			  "\t array %.*s.\n",MAX_NC_NAME,MSLOPE,MAX_NC_NAME,arrayname);
		      
            MAPIERR(buff,funcname);
	    free(temp_value);
	    return(MFAIL);
	}
	else
	 {
	  sprintf(buff, "WARNING: scale_factor attribute for array %.*s not found.\n"
			      "\t scale_factor set to 1.\n", MAX_NC_NAME,arrayname);
	    MAPIWARN(buff, funcname);
	    scale_factor = 1;
	 }
  }
  	
	


  /* Retrieve add_offset */
  if (getMODISarinfo(file, (char*)arrayname, (char*)groupname, MOFFSET,
      attr_datatype, &attr_n_elements, &add_offset) != MAPIOK)
  {
  	if (attr_n_elements == 0)
	{
         sprintf(buff,"ERROR: modisL2reader detected MFAIL from M-API procedure\n"
                         "\t getMODISarinfo while retrieving attribute %.*s from\n"
			 "\t array %.*s.\n", MAX_NC_NAME,MOFFSET,MAX_NC_NAME,arrayname);
		      
            MAPIERR(buff,funcname);
	    free(temp_value);
	    return(MFAIL);
	}
	else
	{
	 sprintf(buff, "WARNING: add_offset attribute for array %.*s not found.\n"
			     "\t add_offset set to zero.\n", MAX_NC_NAME,arrayname);
	    MAPIWARN(buff, funcname);
	    add_offset = 0;
	}
  }
  	
  /* Retrieve FillValue */
  if (getMODISarinfo(file, (char*)arrayname, (char*)groupname, MFILL_VALUE,
      datatype, &attr_n_elements,FillValue) != MAPIOK)
  {
	if (attr_n_elements == 0)
	{		     
         sprintf(buff,"ERROR: modisL2reader detected MFAIL from M-API procedure\n"
                         "\t getMODISarinfo while retrieving attribute %.*s from\n"
			 "\t array %.*s.\n", MAX_NC_NAME,MFILL_VALUE,MAX_NC_NAME,arrayname);
		       
            MAPIERR(buff,funcname);
            free(temp_value);
            return(MFAIL);
        }
       else
         {
         sprintf (buff, "WARNING: _FillValue attribute for array %.*s not found.\n"
			      "\t _FillValue set to default.\n", MAX_NC_NAME,arrayname);
	   
	   MAPIWARN(buff, funcname);
  
           if  (strcmp(datatype,I8) == 0)
  	    (((int8 *)FillValue)[0] = FILL_BYTE);

           else if (strcmp(datatype,I16) == 0)
    	    (((int16 *)FillValue)[0] = FILL_SHORT);
  
           else if (strcmp(datatype,I32) == 0)
   	    (((int32 *)FillValue)[0] = FILL_LONG);

           else if (strcmp(datatype,R32) == 0)
  	    (((float32 *)FillValue)[0] = FILL_FLOAT);

           else if (strcmp(datatype,R64) == 0)
   	    (((float64 *)FillValue)[0] = FILL_DOUBLE);
	   
	   else if (strcmp(datatype,UI8) == 0)
   	    (((uint8 *)FillValue)[0] = 0);
	    
	   else if (strcmp(datatype,UI16) == 0)
   	    (((uint16 *)FillValue)[0] = 0);
	    
	   else if (strcmp(datatype,UI32) == 0)
   	    (((uint32 *)FillValue)[0] = 0);
	 }
  } 

  

  /* Set add_offset */
  if (control_flag[0] == 1)
     add_offset = (-1.0)*add_offset;

  /* Set scale_factor */
  if (control_flag[1] == 1)
     scale_factor = 1.0/scale_factor; 



  /* Convert retrieved array to geophysical data */
  if (strcmp(datatype,I8) == 0) 
  {
    for (i=0; i<n_elements; i++)
      if (((int8 *)temp_value)[i] != ((int8 *)FillValue)[0]) 
         ((double *)value)[i] = (((int8 *)temp_value)[i] - add_offset)/scale_factor;
	
      else
         ((double *)value)[i] = ((double)Fill_Value);
  }
  
  else if (strcmp(datatype,UI8) == 0)
  {
  for (i=0; i<n_elements; i++)
      if (((uint8 *)temp_value)[i] != ((uint8 *)FillValue)[0] || (((uint8 *)FillValue)[0] == 0))
         ((double *)value)[i] = (((uint8 *)temp_value)[i] - add_offset)/scale_factor;
	
      else
         ((double *)value)[i] = ((double)Fill_Value);
  }
  

  else if (strcmp(datatype,I16) == 0)  
  {
    for (i=0; i<n_elements; i++)
      if (((int16 *)temp_value)[i] != ((int16 *)FillValue)[0])
         ((double *)value)[i] = (((int16 *)temp_value)[i] - add_offset)/scale_factor;
      else
         ((double *)value)[i] = ((double)Fill_Value);
  }
  
  else if(strcmp(datatype,UI16) == 0)
  {
      for (i=0; i<n_elements; i++)
      if (((uint16 *)temp_value)[i] != ((uint16 *)FillValue)[0] || (((uint16 *)FillValue)[0] == 0))
         ((double *)value)[i] = (((uint16 *)temp_value)[i] - add_offset)/scale_factor;
      else
         ((double *)value)[i] = ((double)Fill_Value);
  }

  else if (strcmp(datatype,I32) == 0)  
  {
    for (i=0; i<n_elements; i++)
      if (((int32 *)temp_value)[i] != ((int32 *)FillValue)[0])
         ((double *)value)[i] = (((int32 *)temp_value)[i] - add_offset)/scale_factor;
      else
         ((double *)value)[i] = ((double)Fill_Value);
  }
  
  else if(strcmp(datatype, UI32) == 0)
  {
   for (i=0; i<n_elements; i++)
      if (((uint32 *)temp_value)[i] != ((uint32 *)FillValue)[0] || (((uint32 *)FillValue)[0] == 0))
         ((double *)value)[i] = (((uint32 *)temp_value)[i] - add_offset)/scale_factor;
      else
         ((double *)value)[i] = ((double)Fill_Value);
  }

  else if (strcmp(datatype,R32) == 0)
  {
    for (i=0; i<n_elements; i++)
      if (fabs(((float32 *)temp_value)[i] - ((float32 *)FillValue)[0]) > FLT_EPSILON)
         ((double *)value)[i] = (((float32 *)temp_value)[i] - add_offset)/scale_factor;
      else
         ((double *)value)[i] = ((double)Fill_Value);
  }

  else if (strcmp(datatype,R64) == 0)
  {
    for (i=0; i<n_elements; i++)
      if (fabs(((float64 *)temp_value)[i] - ((float64 *)FillValue)[0]) > DBL_EPSILON) 
         ((double *)value)[i] = (((float64 *)temp_value)[i] - add_offset)/scale_factor;
      else
         ((double *)value)[i] = ((double)Fill_Value);
  }

    free(temp_value);

  return(status);
}

/********* END modisL2reader.c *********/
