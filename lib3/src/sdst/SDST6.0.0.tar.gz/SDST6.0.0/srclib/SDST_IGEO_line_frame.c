/********************** filename SDST_IGEO_line_frame.c *************
* SDST_IGEO_line_frame.c contains SDST_IGEO_calc_line_frame_par(),
* SDST_IGEO_estimate_line_frame() and SDST_IGEO_calibrate_scan_par().
* Revision history:
* $Log: SDST_IGEO_line_frame.c,v $
* Revision 1.6  2000/04/17 20:20:40  kuyper
* Made implicit conversions explicit.
*
 * Revision 1.5  1999/11/29  20:50:13  kuyper
 * Corrected order of argument in call to SDST_IGEO_calc_line_frame_par().
 *
 * Revision 1.4  1999/11/03  21:14:46  lma
 * correct include files.
 *
 * Revision 1.3  1999/11/03  16:19:24  lma
 * updated after walkthrough.
 *
 * Revision 1.2  1999/10/20  15:00:27  lma
 * added function SDST_IGEO_calibrate_scan_par().
 *
* Revision 1.1  1999/09/03  15:06:52  jayshree
* Initial revision
*
* Revision 1.1  1999/08/12  19:51:18  jayshree
* Initial revision
*/


#include <math.h>
#include "PGS_TYPES.h"
#include "PGS_SMF.h"
#include "PGS_CSC.h"
#include "PGS_MODIS_39604.h"
#include "SDST_IGEO_line_frame.h"

#ifndef STATIC
#define STATIC static
#endif


static PGSt_SMF_status SDST_IGEO_calc_line_frame_par (
		           const scan_info_struct	* const scan_info,
	        	   const PGSt_double	ecr_position[3],
		           double * const lambda,
		           double * const phi )

/*
!C*****************************************************************************
*
*
*!Description :
*	Calculates the parameters for a given position that are supposed to be
*	linearly related to the line and frame numbers within a given scan.
*
*
*!Input Parameters:
*	scan_info	Information about the scan.
*	ecr_position	The requested position.
*
*!Output Parameters:
*	lambda		The parameter related to the line number.
*	phi		The parameter related to the frame number.
*
*
*!Return Value:
*	MODIS_N_SDST_IGEO_NOTFOUND	The requested position is too near the 
*					mirror axis.
*	PGS_S_SUCCESS			Otherwise	
*
*!Global Variables:
*	None
*
*!Called by:
*	SDST_IGEO_calibrate_scan_par
*	SDST_IGEO_estimate_line_frame
*
*!Calls Function
*	None
*
*
*!Revision History
* See top of file.
*
*
*!Requirements:
*	CCR-468
*
*
*!Team-unique Header:
*	This software is developed by the MODIS Science Data Support
*	Team for the National Aeronautics and Space Administration, 
*	Goddard Space Flight Center, under contract NAS5-32373.
*
*
*!References and Credits:
*	HDF portions of this code were developed at the National Center
*	for Supercomputing Applications at the University of Illinois at 
*	Urbana-Champaign
*
*
!END ************************************************************************************
*/
{

PGSt_double	scan_view[3];
PGSt_double	view_ecr[3];
double		rho;
int		scn;
int 		i;



    for (i=0; i<3; i++)
    	view_ecr[i] = ecr_position[i] - scan_info->sc_position[i]; 
    
    for (scn=0; scn<3 ; scn++)
    	scan_view[scn] = PGS_CSC_dotProduct((PGSt_double *)scan_info->T_ecr2scan[scn], view_ecr, 3); 
	
	
     *phi = atan2(scan_view[1], scan_view[0]);
     rho = sqrt((scan_view[0]*scan_view[0]) + (scan_view[1]*scan_view[1]));
    
    if (rho < fabs(scan_view[2])) 
    	return (MODIS_N_SDST_IGEO_NOTFOUND); 
	
     *lambda = scan_view[2]/rho;
    
    return(PGS_S_SUCCESS);
    
}






PGSt_SMF_status SDST_IGEO_estimate_line_frame (
			const scan_info_struct * scan_info,
			const PGSt_double ecr_position[3],
			double  * dline,
			float32 * dframe)

/*
!C*************************************************************************************
*
*
*!Description :
*	Estimates the line and frame numbers corresponding to a given 
*	position within a given scan.
*
*
*!Input Parameters:
*	scan_info	Information about the scan.
*	ecr_position	The requested position.
*
*!Output Parameters:
*	dline		Fractional estimated line number.
*	dframe		Fractional estimated frame number.
*
*
*!Return Value:
*	MODIS_E_SDST_IGEO_INTERNAL	If any argument is null.
*	MODIS_N_SDST_IGEO_NOTFOUND	If too near mirror axis.
*	PGS_S_SUCCESS			Otherwise
*
*!Global Variables:
*	None
*
*
*!Called by:
*	SDST_IGEO_locate_line_frame
*
*
*!Routines called:
*	SDST_IGEO_calc_line_frame_par
*
*
*!Revision History
*	See Revision History at the top of file
*
*!Requirements:
*	CCR-468
*
*
*!Team-unique Header:
*	This software is developed by the MODIS Science Data Support
*	Team for the National Aeronautics and Space Administration, 
*	Goddard Space Flight Center, under contract NAS5-32373.
*
*
*!References and Credits:
*	HDF portions of this code were developed at the National Center
*	for Supercomputing Applications at the University of Illinois at 
*	Urbana-Champaign
*
*
*
!END ***************************************************************************************
*/
{

 double lambda;
 double phi;
 PGSt_SMF_status status;

	

    if (scan_info == NULL || ecr_position == NULL || dline == NULL || dframe == NULL)
    { 
    return(MODIS_E_SDST_IGEO_INTERNAL); }
    
    status =
	SDST_IGEO_calc_line_frame_par(scan_info, ecr_position, &lambda, &phi);
    if (status != PGS_S_SUCCESS){
    return (status);
    }
    
    *dline = scan_info->center_line + (lambda*scan_info->lines_per_radian);
    *dframe = (float32)(scan_info->center_frame +
	(phi*scan_info->frames_per_radian));
    
    return (PGS_S_SUCCESS);
    
	
	
}
	
	
	
PGSt_SMF_status SDST_IGEO_calibrate_scan_par(
                    scan_info_struct              *scan_info,
                    const frame_info_struct       frame_info[])
/*
!PROLOG*************************************************************************
!Description:
       Calibrates the relationships between the values returned by
       SDST_IGEO_calc_line_frame_par() and the line and frame numbers.


!Input Parameters:
       frame_info      The two frames used in to set up the scan coordinates

!Output Parameters:
        None

!Input/Output Parameters:
        scan_info       Information about the scan.

Return Value:
        MODIS_E_SDST_IGEO_INTERNAL          if either argument is NULL.
        MODIS_W_SDST_IGEO_INTERNAL          If the relationship is underdetermined
                                            propably due to bad data.
        PGS_S_SUCCESS                       Otherwise

Global variables:       None

Called by:
        SDST_IGEO_get_scan()

Calls functions:
        SDST_IGEO_calc_line_frame_par()

!Requirements:
         124, 468

!Revision History:
See top of file.

!Team-unique Header:
        This software is developed by the MODIS Science Data Support
        Team for the National Aeronautics and Space Administration,
        Goddard Space Flight Center, under contract NAS5-32373.

!END****************************************************************************
*/

{
   const frame_info_struct   *high;
   const frame_info_struct   *low;
   double              lambda_hi;
   double              lambda_lo;
   double              phi_hi;
   double              phi_lo;
   PGSt_SMF_status     status;
   


   if( (scan_info == NULL) || (frame_info == NULL) )
      return MODIS_E_SDST_IGEO_INTERNAL;

   /* Find the most widely seperated pair of a first_det from one frames.
    * and a last_det from the other. It's guaranteed that one of these two
    * differences is greater than 0 if det numbers are valid.
    */
   if(frame_info[0].last_det - frame_info[1].first_det >
      frame_info[1].last_det- frame_info[0].first_det) {
      high = &frame_info[0];
      low  = &frame_info[1];
   } else {
      high = &frame_info[1];
      low  = &frame_info[0];
   }

   status = SDST_IGEO_calc_line_frame_par(scan_info, 
                 scan_info->position[high->last_det][high->iframe],
                 &lambda_hi, &phi_hi);
   if(status != PGS_S_SUCCESS)
      return MODIS_W_SDST_IGEO_INTERNAL;

   status = SDST_IGEO_calc_line_frame_par(scan_info,
                 scan_info->position[low->first_det][low->iframe],
                 &lambda_lo, &phi_lo);
   if(status != PGS_S_SUCCESS)
      return MODIS_W_SDST_IGEO_INTERNAL;

   /* Check against division by zero. */
   if((fabs(lambda_hi - lambda_lo) < DBL_MIN)|| (fabs(phi_hi - phi_lo) < DBL_MIN))
      return MODIS_W_SDST_IGEO_INTERNAL;

   scan_info->lines_per_radian = 
	  (double)(high->last_det - low->first_det) / ( lambda_hi - lambda_lo);
   scan_info->frames_per_radian = 
          (double)(high->iframe - low->iframe) / ( phi_hi - phi_lo);

   scan_info->center_frame = ((double)low->iframe*phi_hi -
       (double)high->iframe*phi_lo)/( phi_hi - phi_lo);
   scan_info->center_line  = ((double)low->first_det*lambda_hi -
       (double)high->last_det*lambda_lo)/( lambda_hi - lambda_lo);


   return PGS_S_SUCCESS;

}
