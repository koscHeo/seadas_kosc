#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "mapic.h"
#include "SDST_TK.h"

/* Function name redefined for c routines called by FORTRAN */
#define ncml2rdr   FNAME(cml2rdr)

/* function prototype */
void ncml2rdr(intf modfile[], intf control_flag[], _fcd arrnm, intf *lar, 
              _fcd grpnm, intf *lgr, intf start[], intf dims[], intf *fillval, 
	      double *data, intf *ret); 


void ncml2rdr(intf modfil[], intf control_flag[], _fcd grpnm, intf *lgr,
	       _fcd arrnm, intf *lar, intf start[], intf dims[], intf *fillval,
	        double *data, intf *ret)

/*****************************************************************************
!C
*
* !Purpose: A wrapping function interfacing between C and FORTRAN for modisL2reader.
*           This C function is only called by FORTRAN function ML2RDR. This 
*	    function is a part of the SDST toolkit.
*
* !Description: Function cml2rdr is part of a larger software system called the 
*               MODIS SDST toolkit.  cml2rdr is a wrapper which is callable from  
*		FORTRAN.  This function will call modisL2reader to read array data. 
*
*               In order to be callable from the FORTRAN in different platforms
*               using function name cml2rdr, this function is called ncml2rdr in the
*               actual C code. ncml2rdr is redefined in SDST_TK.h according to the 
*               compiler's FORTRAN naming conventions/conversion of each platform, 
*		so that the object name of ncml2rdr will always be the object name 
*		of a FORTRAN function named cl2rdr.
*               
*
* !Input Parameters:
*
*               modfil  IN: FORTRAN integer array that is used to reference the
*                           MODIS-HDF file.
*
*	  control_flag  IN: Control flag indication the operation being performed
*			
*			If control_flag[0] equals zero:
*			add_offset is subtracted from the retrieved array
*
*			If control_flag{0] does not equal zero:
*			add_offset is added to the retrieved array
*
*			If control_flag[1] equals zero:
*			retrieved array is divided by the scale_factor
*
*			If control_flag[1] does not equal zero:
*			retrieved array is multiplied by the scale_factor
*
*
*               arrnm   IN: FORTRAN character string that is the name of the array.
*
*               lar     IN: FORTRAN integer address of the memory size of arrnm.
*
*               grpnm   IN: FORTRAN character string name of the data group
*                           containing the SDS array.
*               lgr     IN: FORTRAN integer address of the memory size of grpnm.
*
*               start   IN: FORTRAN integer array containing the array structure
*                           location to begin reading the data from the array 
*                           structure, start must have the same number of elements
*                           as the target array has dimensions.
*
*               dims    IN: FORTRAN integer array describing the size of the array
*                           being retrieved from the array structure. dims  must
*                           have  the same number of elements as the target array 
*                           structure has dimensions.  The product of the array 
*                           dimensions must equal the number of elements in data.
*
*	      fillval   IN: FORTRAN integer to be input by the user.  
*			    This Fill_Value will be written in the output array.
*
*
* !Output Parameters:
*               data   OUT: Multi-dimensional data array.
*
*               ret     OUT: FORTRAN integer address of the status(MFAIL, MAPIOK)
*
* !Returns:     none
*
* !Called by :  FORTRAN routine ML2RDR.f
*
* !Routines called :   getMODISarrayid
*
* !External references:
*                      MODFILE                  (mapi.h)
*                      DATAID                   (mapic.h)
*                      MAX_VAR_DIMS             (netcdf.h)
*                      P_ADDR                   (mapic.h)
*                      HDf2string               (hproto.h)
*                      HDfreespace              (hproto.h)                      
*                      VOIDP                    (hdfi.h)                     
*                      MFAIL                    (mapic.h)
* 
*
* !Revision History:
*               Jayshree Murthy               Oct 1, 1998
*               Version 2.1
*               Orginal Development and Testing
*  $LOG$
*
* !Team-unique Header:
*  This software is developed by the MODIS Science Data Support Team for the
*  National Aeronautics and Space Administration, Goddard Space Flight Center,
*  under contract NAS5-32373.
*
*  Portions developed at the National Center for Supercomputing Applications
*  at the Univ. of Illinois at Urbana-Champaign.
*
* !References and Credits:
* 
*
* !Design Notes:
*
* !END***********************************************************************
*/

{
    MODFILE  *mfile;
    char *carrnm, *cgrpnm;
    long int cstart[MAX_VAR_DIMS], cdims[MAX_VAR_DIMS];
    int ccontrol_flag[MAX_VAR_DIMS];
    DATAID *did;
    long int rank, i;
   
    
    
    /* 
       Convert FORTRAN character strings arrnm and grpnm to C character
       strings carrnm and cgrpnm by using HDf2cstring.
    */
    
    
    cgrpnm  = HDf2cstring(grpnm, (intn)*lgr);
    carrnm = HDf2cstring(arrnm, (intn)*lar);
    
    memcpy (&mfile, &modfil[P_ADDR], sizeof(MODFILE *));
    
    did = getMODISarrayid(mfile, carrnm, cgrpnm);
    
    if (did == NULL) {
    	if (cgrpnm) HDfreespace ((VOIDP)cgrpnm);
	if (carrnm) HDfreespace ((VOIDP)carrnm);
	*ret = MFAIL;
	return;
	}
	
	rank = ((SDSINFO *)did->info)->rank;
	
    
    /* First dimension in FORTRAN becomes last dimension in C */
    
    for (i = 0; i<= rank - 1; i++) {
    	cstart[i] = start[(rank-i)-1];
	cdims[i] = dims[(rank-i)-1];
	ccontrol_flag[i] = control_flag[(rank-i)-1];
	}
	
	*ret = modisL2reader(mfile, ccontrol_flag, cgrpnm, carrnm, cstart, cdims, *fillval, data);
	
	
	if(cgrpnm) HDfreespace((VOIDP)cgrpnm);
	if(carrnm) HDfreespace((VOIDP)carrnm);
	
    return;
    
}
	



