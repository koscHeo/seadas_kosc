/********************** filename SDST_IGEO_get_scan.c *********************/
/*
 * SDST_IGEO_get_scan.c contains SDST_IGEO_load_scan() and 
 * SDST_IGEO_get_scan().
 * 
 * Revision history:
 * $Log: SDST_IGEO_get_scan.c,v $
 * Revision 3.2  2001/10/16 18:57:33  kuyper
 * Corrected type of iscan.
 *
 * Revision 3.1  2001/10/15 20:56:27  kuyper
 * Changed to store a larger number of scans of data, to match the increased
 *   range of scan numbers searched by SDST_IGEO().
 *
 * Revision 1.5  2000/04/21 15:36:29  kuyper
 * Corrected order of shifts done to sc_list.
 *
 * Revision 1.4  2000/04/17  20:22:29  kuyper
 * Corrected data types of 'line', 'ent', and 'i'.
 *
 * Revision 1.3  1999/12/16  15:34:13  lma
 * Corrected MODIS_E_SDST_IGEO_BAD_DATA messages to include filename.
 *
 * Revision 1.2  1999/11/29  20:49:38  kuyper
 * Corrected upper limits on frame loops.
 *
 * Revision 1.1  1999/11/03  16:10:11  lma
 * Initial revision
 *
*/

#include "PGS_TYPES.h"
#include "PGS_SMF.h"
#include "PGS_CSC.h"
#include "PGS_MODIS_39604.h"
#include "SDST_IGEO_calc_scan.h"
#include "SDST_IGEO_line_frame.h"
#include "SDST_IGEO_get_scan.h"
#include "mapiL1Bgeo.h"
#include "smfio.h"

#define MAX_ENTRIES    10

static PGSt_SMF_status SDST_IGEO_load_scan(
                MODFILE                 * const geo_file,
		scan_info_struct	* const scan_info)

/*
!C**************************************************************************
*
*
*!Description :
*	Loads the raw data from the geolocation file needed to perform inverse
*       geolocation.
*
*
*!Input Parameters:
*	geo_file                M-API file handle of geolocation file
*
*!Output Parameters:
*	scan_info               Scan information structure.
*
*
*!Return Value:
*	MODIS_E_SDST_IGEO_BAD_DATA   The geolocation file contains corrupt data.
*	MODIS_E_SDST_IGEO_READ       If an error was detected reading the
*	                             geolocation file
*       PGS_S_SUCCESS		     Otherwise
*
*!Global Variables:
*	None
*
*!Called by:
*	SDST_IGEO_get_scan
*
*!Routines called:
*	modsmf
*       PGS_CSC_GEOtoECR
*
*!Revision History
*See top of file.
*
*!Requirements:
*	CCR-468
*
*
*!Team-unique Header:
*	This software is developed by the MODIS Science Data Support
*	Team for the National Aeronautics and Space Administration, 
*	Goddard Space Flight Center, under contract NAS5-32373.
*
*
*!References and Credits:
*	HDF portions of this code were developed at the National Center
*	for Supercomputing Applications at the University of Illinois at 
*	Urbana-Champaign
*
*
!END ***************************************************************************
*/
{
   long     dimsizes[2];
   long     start[2];
   float32  latitude[MAX_DETS][MAX_FRAMES];
   float32  longitude[MAX_DETS][MAX_FRAMES];
   char     msgbuf[128];
   long     line;
   int16    frame;
   int      i;

   /* Note: getMODISarray's status messages always indicate the array name if it's
    * not NULL, and the dimensions if they don't fit. The only additional data our
    * messages need supply is the filename, which will be printed by IGEO_get_scan().
    */


   dimsizes[0] = 1L;
   dimsizes[1] = 0L;
   start[0] = (long)scan_info->iscan;
   start[1] = 0L;

   if(getMODISarray( geo_file, M03EV_FRAMES, "", start, dimsizes, 
      &scan_info->EV_frames) != MAPIOK)
      return MODIS_E_SDST_IGEO_READ;

   if((scan_info->EV_frames <0)||(scan_info->EV_frames >MAX_FRAMES)) {
      sprintf(msgbuf, " %s for scan:(%ld), %s = %d ", geo_file->filename,
              (long)scan_info->iscan, M03EV_FRAMES, scan_info->EV_frames);
      modsmf(MODIS_E_SDST_IGEO_BAD_DATA, msgbuf, __FILE__ ", SDST_IGEO_load_scan");

      return MODIS_E_SDST_IGEO_BAD_DATA;
   }
  
   dimsizes[0]=1L;
   dimsizes[1]=3L;

   if(getMODISarray( geo_file, M03ORB_POS, "", start, dimsizes,
      scan_info->sc_position) != MAPIOK)
      return MODIS_E_SDST_IGEO_READ;

   if(scan_info->EV_frames == 0)
      return PGS_S_SUCCESS;

   start[0] = (long)(MAX_DETS*scan_info->iscan);
   if(scan_info->EV_frames == MAX_FRAMES)
      /* Normal case: can process entire array at once. */
      dimsizes[0] = MAX_DETS;
   else
      /* Length is less than 2nd dimension of storage arrays, must load one row at
        * a time */
      dimsizes[0] = 1;

   start[1] = 0;
   dimsizes[1] = (long)(scan_info->EV_frames);

   for(line=0; line<MAX_DETS; line+=dimsizes[0]){
      if(getMODISarray( geo_file, M03LATITUDE, "", start, dimsizes,
	  latitude[line]) != MAPIOK)
         return MODIS_E_SDST_IGEO_READ;

      if(getMODISarray( geo_file, M03LONGITUDE, "", start, dimsizes,
	  longitude[line]) != MAPIOK)
         return MODIS_E_SDST_IGEO_READ;

      if(getMODISarray( geo_file, M03GFLAGS, "", start, dimsizes,
	  scan_info->gflags[line]) != MAPIOK)
         return MODIS_E_SDST_IGEO_READ;
      start[0] += dimsizes[0];
   }


   for(line=0; line<MAX_DETS; line++){
      for(frame = 0; frame< scan_info->EV_frames; frame++){
         if(scan_info->gflags[line][frame] > INVALID_SENSOR_RANGE){
            for(i=0; i<3; i++){
               scan_info->position[line][frame][i] = 0.0;
            }
            /* Note: Since this value is used to indicate bad data, MAX_DIST
             * must be smaller than the distance from this point to any valid
             * point on the Earth's surface.
             */
         }else{
            longitude[line][frame] *= (float)DEG2RAD;
            latitude[line][frame] *= (float)DEG2RAD;
            if(PGS_CSC_GEOtoECR((PGSt_double)longitude[line][frame],
	      (PGSt_double)latitude[line][frame], 0.0, "WGS84",
               scan_info->position[line][frame]) != PGS_S_SUCCESS){

               sprintf(msgbuf,
		 " %s for scan:(%d), line(%ld), frame(%d), %s = %f, %s = %f", 
                 geo_file->filename, scan_info->iscan, line, frame, M03LATITUDE,
                 latitude[line][frame], M03LONGITUDE, longitude[line][frame]);

               modsmf(MODIS_E_SDST_IGEO_BAD_DATA, msgbuf,
		   __FILE__ ", SDST_IGEO_load_scan");

               return MODIS_E_SDST_IGEO_BAD_DATA;
            }
         }
      }
   }

   return PGS_S_SUCCESS;

}

PGSt_SMF_status SDST_IGEO_get_scan(
	MODFILE			*geo_file,
	int32			iscan,
	scan_info_struct	**scan_info)
/*
!PROLOG*************************************************************************
!Description:
       Locates the information needed by inverse geolocation for one scan. If
       not found, retrieves it from the geo_file.


!Input Parameters:
       geo_file         M-API file handle for the geolocation file.
       iscan            The number of the scan to be located.

!Output Parameters:
        scan_info        The location where the scan information was found.



Return Value:
        MODIS_E_SDST_IGEO_BAD_DATA* The geolocation file contains corrupt data.
        MODIS_E_SDST_IGEO_READ*     I/O error while reading geolocation file.
        MODIS_E_SDST_IGEO_INTERNAL* Fatal internal error in self or subroutines
        MODIS_E_SDST_IGEO_MEM       Insufficient memory.
        MODIS_W_SDST_IGEO_INTERNAL* Non-fatal internal error.
        MODIS_N_SDST_IGEO_NOTFOUND  Couldn't use the scan
        PGS_S_SUCCESS               Successful return.
* - passed on from subroutines; not returned directly from this function.


Global variables:       None

Called by:
        SDST_IGEO_get_graninfo()

Routines called:
        SDST_IGEO_load_scan()
        SDST_IGEO_calc_scan_coords()
        SDST_IGEO_calibrate_scan_par()

Requirements:
         CCR 468

!Revision History:
See top of file.

!Team-unique Header:
        This software is developed by the MODIS Science Data Support
        Team for the National Aeronautics and Space Administration,
        Goddard Space Flight Center, under contract NAS5-32373.

!END****************************************************************************
*/

{
    unsigned                   ent,i;
    static  unsigned           num_used = 0;
    static  scan_info_struct   *sc_list[MAX_ENTRIES] = {NULL};
    scan_info_struct           *temp;
    frame_info_struct          frame_info[2];
    PGSt_SMF_status            status;

    if(geo_file == NULL){

       for(ent = 0; ent <  num_used; ent++){
          free(sc_list[ent]);
       }

       num_used = 0;
       return PGS_S_SUCCESS;
    }


    for(ent=0; ent<num_used && sc_list[ent]->iscan != iscan; ent++);
    
    if(ent == num_used){
       if(num_used < MAX_ENTRIES){
          sc_list[num_used] =
	    (scan_info_struct*)malloc(sizeof(scan_info_struct));
          if(sc_list[num_used] == NULL) {
             if(num_used == 0){ /*Not enough memory for even one entry! */
                modsmf(MODIS_E_SDST_IGEO_MEM, "",
		    __FILE__ ", SDST_IGEO_get_scan");
                return MODIS_E_SDST_IGEO_MEM;
             }

             /* Fall back to overwriting least-recently-used entry.*/
             num_used--;
          }
        
       }else{ /* We'll have to overwrite the least recently used entry. */
          num_used--;
       }
       
       sc_list[num_used]->iscan = iscan;
       status = SDST_IGEO_load_scan(geo_file, sc_list[num_used]);
       if(status != PGS_S_SUCCESS){
          modsmf(MODIS_E_SDST_IGEO_READ, geo_file->filename,
	      __FILE__ ", SDST_IGEO_get_scan");
          free(sc_list[num_used]);
          return MODIS_E_SDST_IGEO_READ;
       }else{
          ent = num_used;
          num_used++;

          status = SDST_IGEO_calc_scan_coords(sc_list[ent], frame_info);
          if(status == PGS_S_SUCCESS){
             status = SDST_IGEO_calibrate_scan_par(sc_list[ent], frame_info);
          }

          if(status != PGS_S_SUCCESS){  /* Mark as bad data. */
             sc_list[ent]->EV_frames = -1;
             return status;
          }
 
       }
    }

    temp = sc_list[ent];

    for(i=ent; i; i--)
    {
       sc_list[i] = sc_list[i-1];
    }

    sc_list[0]= temp;


    if(sc_list[0]->EV_frames == -1){
       return MODIS_N_SDST_IGEO_NOTFOUND;
    }


    *scan_info = sc_list[0];

    return PGS_S_SUCCESS;
}

