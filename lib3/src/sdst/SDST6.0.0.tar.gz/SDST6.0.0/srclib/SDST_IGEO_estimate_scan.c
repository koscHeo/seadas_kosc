/********************* filename SDST_IGEO_estimate_scan.c *******************/
/*
 * SDST_IGEO_estimate_scan.c contains SDST_IGEO_get_orbit_angle(),
 * SDST_IGEO_estimate_scan_number() and SDST_IGEO_calibrate_gran_par().
 *
 * Revision history:
 * $Log: SDST_IGEO_estimate_scan.c,v $
 * Revision 5.1  2009/06/26 18:34:40  kuyper
 * Corrected to treat values for 'numerator' that are slightly larger than
 *   rtrans2 as being the result of round-off error in a calculation that
 *   should have left them essential equal; thereby resolving Bug 1152.
 *
 * James Kuyper		James.R.Kuyper@nasa.gov
 *
 * Revision 1.3  2000/04/17 20:23:28  kuyper
 * Corrected handling of NULL pointers.
 *
 * Revision 1.2  2000/03/28  15:06:42  fhliang
 * changed logical operator from '||' to '&&' per PDL after call to
 * PGS_CSC_GrazingRay() in function SDST_IGEO_calibrate_gran_par().
 *
 * Revision 1.1  2000/02/28  17:03:41  lma
 * Initial revision
 *
*/


#include "PGS_TYPES.h"
#include "PGS_SMF.h"
#include "PGS_CSC.h"
#include "PGS_MODIS_39604.h"
#include "SDST_IGEO_calc_scan.h"
#include "SDST_IGEO_get_scan.h"
#include "SDST_IGEO_estimate_scan.h"
#include "SDST_IGEO_get_gran.h"
#include "mapi.h"
#include "mapiL1Bgeo.h"
#include "smfio.h"
#include "math.h"


#define EARTH_MODEL "WGS84"

static PGSt_SMF_status SDST_IGEO_get_orbit_angle(
		const graninfo_struct        *graninfo,
                const PGSt_double             ecr_position[],
                double                        *orbit_angle)

/*
!C**********************************************************************
*!Description :
*       Estimate the orbit angle relative to a specified granule for a given
*       position.
*
*
*!Input Parameters:
*       graninfo        Granule level information needed by inverse geolocation
*       ecr_position    Requested position in ECR coordinates.
*
*!Output Parameters:
*       orbit_angle     The estimated orbit angle.
*
*
*!Return Value:
*       MODIS_E_SDST_IGEO_INTERNAL   If certain "impossible" errors occur.
*       MODIS_N_SDST_IGEO_NOTFOUND   If the geometry doesn't allow the calculation
*       PGS_S_SUCCESS                Otherwise
*
*!Global Variables:
*	None
*
*!Called by:
*       SDST_IGEO_estimate_scan_number()
*       SDST_IGEO_calibrate_gran_par()
*
*!Routines called:
*       PGS_CSC_dotProduct()
*
*!Revision History:
*See top of file.
*
*!Requirements:
*	CCR-468
*
*
*!Team-unique Header:
*	This software is developed by the MODIS Science Data Support
*	Team for the National Aeronautics and Space Administration, 
*	Goddard Space Flight Center, under contract NAS5-32373.
*
*
*!References and Credits:
*	HDF portions of this code were developed at the National Center
*	for Supercomputing Applications at the University of Illinois at 
*	Urbana-Champaign
*
*
!END *******************************************************************
*/
{
   double        deltaz;                /* Difference in position perpendicular to scan plane*/
   int           gran;                  /* Index for granule coordinates */
   PGSt_double   gran_position[3];      /* position in granule coordinates */
   double        numerator;
   double        rotated[2];            /* rotated copy of transverse component */
   double        rtrans2;               /* Square of component of position transverse axis */
   double        sqrt_arg;
   

   if((fabs(graninfo->mirror_axis[1])<DBL_MIN) || 
      (fabs(graninfo->mirror_trans2)<DBL_MIN))
   /* Mirror axis has no component along-track. This means that scan
    * numbers are indeterminate, which would require a division by zero
    * below.
    */
   {
      return MODIS_N_SDST_IGEO_NOTFOUND;
   }


   for(gran=0; gran<3; gran++)
   {
      gran_position[gran] =
             PGS_CSC_dotProduct((PGSt_double*)graninfo->T_ecr2gran[gran], (PGSt_double*)ecr_position,3);
   }

   rtrans2 = gran_position[0]*gran_position[0]+gran_position[1]*gran_position[1];

   /* This will typically be very small compared to Earth's radius. */
   deltaz = graninfo->mirror_perp - gran_position[2]*graninfo->mirror_axis[2];
   sqrt_arg = graninfo->mirror_trans2*rtrans2 - deltaz*deltaz;

   if(sqrt_arg <0 )
   {
      return MODIS_N_SDST_IGEO_NOTFOUND;
   }

   /* rotated[] contains the first two components of gran_position[], rotatated
    * about the orbital axis far enough to intersect the mirror's center scan
    * plane.
    */
   rotated[0] = (graninfo->mirror_axis[0]*deltaz +
        fabs(graninfo->mirror_axis[1])*sqrt(sqrt_arg))/graninfo->mirror_trans2;

   rotated[1] = (deltaz - rotated[0]*graninfo->mirror_axis[0])/graninfo->mirror_axis[1];

   numerator = rotated[0]*gran_position[1] - rotated[1]*gran_position[0];

   if(numerator > rtrans2*(1.0+DBL_EPSILON*4.0))
      return MODIS_E_SDST_IGEO_INTERNAL;

   /* Division by rtrans2 is safe, because it is guaranteed non-zero by the
    * non-negative value of sqrt_arg, and the positive value of
    * graninfo.mirror_trans2, both of which have already been checked.
    */
   *orbit_angle = (numerator > rtrans2 ? 90.0*DEG2RAD :
       asin(numerator/rtrans2));

   return PGS_S_SUCCESS;
}







PGSt_SMF_status SDST_IGEO_estimate_scan_number(
                PGSt_double const      ecr_position[],
                MODFILE* const         geo_file,
                graninfo_struct* const graninfo,
                double* const          dscan)


/*
!C**********************************************************************
*!Description :
*       Estimates the number of the scan within a granule which is closest to
*       the requested point.
*
*
*!Input Parameters:
*       ecr_position    The requested position in ECR coordinates.
*       geo_file        The M-API file handle for the geolocation file.
*
*!Output Parameters
*       dscan           The estimated scan number.
*
*!Input/Output Parameters:
*       graninfo        Granule level information needed by inverse geolocation.
*
*Return Value:
*        MODIS_E_SDST_IGEO_BAD_ARG    If geo_file->filename is NULL
*        MODIS_E_SDST_IGEO_READ       Error while reading geolocation file
*        MODIS_E_SDST_IGEO_INTERNAL   Fatal internal error
*        MODIS_W_SDST_IGEO_INTERNAL   Non-Fatal internal error
*        MODIS_N_SDST_IGEO_NOTFOUND   Granule contains no usable scans
*        PGS_S_SUCCESS           Otherwise
*
*!Global Variables:
*       None
*
*!Called by:
*       SDST_IGEO()
*
*!Routines called:
*       SDST_IGEO_get_graninfo()
*       SDST_IGEO_get_orbit_angle()
*
*
*!Revision History:
*See top of file.
*
*
*!Requirements:
*       CCR-468
*
*
*!Team-unique Header:
*       This software is developed by the MODIS Science Data Support
*       Team for the National Aeronautics and Space Administration,
*       Goddard Space Flight Center, under contract NAS5-32373.
*
*
*!References and Credits:
*       HDF portions of this code were developed at the National Center
*       for Supercomputing Applications at the University of Illinois at
*       Urbana-Champaign
*
*
!END *******************************************************************
*/
{
   double           orbit_angle;
   PGSt_SMF_status  status;

   if( (graninfo == NULL)||(ecr_position == NULL) ||(dscan == NULL))
       return MODIS_E_SDST_IGEO_INTERNAL;

   if(geo_file == NULL)
       return SDST_IGEO_get_graninfo(geo_file, graninfo);

   if(geo_file->filename == NULL)
   {
       modsmf(MODIS_E_SDST_IGEO_BAD_ARG, "geo_file->filename is NULL", 
	  __FILE__ ", SDST_IGEO_estimate_scan()");
       return MODIS_E_SDST_IGEO_BAD_ARG;
   }

   if(graninfo->filename == NULL ||
       strcmp(geo_file->filename , graninfo->filename))
   {
      status = SDST_IGEO_get_graninfo(geo_file, graninfo);

      if(status != PGS_S_SUCCESS)
         if(status <MODIS_E_SDST_IGEO_INTERNAL)
            return MODIS_E_SDST_IGEO_INTERNAL;
         else
            return status;
   }

   
   status = SDST_IGEO_get_orbit_angle(graninfo, ecr_position, &orbit_angle);
   if(status != PGS_S_SUCCESS)
      return status;

   *dscan = graninfo->first_scan + orbit_angle*graninfo->scans_per_radian;


   return PGS_S_SUCCESS;

}




PGSt_SMF_status SDST_IGEO_calibrate_gran_par(
                scan_info_struct* const  scan_info[2],
                graninfo_struct* const   graninfo)
/*
*!C*********************************************************************
*!Description:
*        Calculates the scans per radian of orbit angle for a given granule.
*
*!Input Parameters:
*        scan_info       A pair of structures for the first and last scans of
*                        the granule.
*
*!Output Parameters:
*        None
*
*!Input/Output Parameters:
*        graninfo        Granule level information needed by inverse geolocation
*
*Return Value:
*        MODIS_E_SDST_IGEO_INTERNAL   If any input pointer is NULL or
*                                     PGS_CSC_GrazingRay fails.
*        MODIS_N_SDST_IGEO_NOTFOUND   If SDST_IGEO_get_orbit_angle() fails due
*                                     to bad geometry.
*        PGS_S_SUCCESS                Otherwise
*
*Global variables:
*        None
*
*Called by:
*        SDST_IGEO_get_graninfo()
*
*Routines called:
*        PGS_CSC_GrazingRay()
*        SDST_IGEO_get_orbit_angle()
*
*
*
*
*Requirements:
*         CCR 468
*
*!Revision History:
*See top of file.
*
*
*!Team-unique Header:
*        This software is developed by the MODIS Science Data Support
*        Team for the National Aeronautics and Space Administration,
*        Goddard Space Flight Center, under contract NAS5-32373.
*
*!END*******************************************************************
*/

{
    PGSt_double      center[3];
    int              ecr;          /**Index for ECR coordinates.*/
    PGSt_double      latitude;     /*Latitude of posNEAR.*/
    PGSt_double      longitude;     /*Longitude of posNEAR.*/
    PGSt_double      missAltitude; /*Altitude of posNEAR..*/
    double           orbit_angle; 
    double           phi;          /*scan angle difference between center */
                                   /*frame and standard center*/
    PGSt_double      posNEAR[3];   /*Point on ray nearest the surface of the Earth, */
                                   /*or if there's an intesection, the midpoint */
                                   /*of the ray chord.*/
    PGSt_double      posSURF[3];   /*Surface position closest to ray. If the ray */
                                   /*intects ellipsoid, the intersection nearest center[].*/
    PGSt_double      ray[3]= {0.0,0.0,0.0};       /*view vector corresponding to center of nominal scan*/
    PGSt_double      slantRange;   /*range from center to posNEAR.*/
    int              sc;           /*Index for scan-oriented coordinates.*/
    PGSt_SMF_status  retval;


    if( (scan_info == NULL)||(graninfo == NULL) ||
        (scan_info[0] == NULL)||(scan_info[1] == NULL)||
        (fabs(scan_info[1]->frames_per_radian)<DBL_MIN)||
        (fabs(scan_info[1]->lines_per_radian)<DBL_MIN))
    {
       return MODIS_E_SDST_IGEO_INTERNAL;
    }

    if(scan_info[0]->iscan == scan_info[1]->iscan)
    {
       graninfo->scans_per_radian = 0;
       return PGS_S_SUCCESS;
    }

/* Calculate the ECR coordinates of a vector pointing from
 * scan_info[1].sc_position to the center of the corresponding scan.
 * Note: there is no pixel exactly at the center of the scan. The nearest
 * usable pixel in a usable frame could be near one of the corners of the scan
 * A short scan may consist entirely of one end of a full scan, going nowhere
 * near the center. By inverting the frame/line estimation formula, all of
 * these problems can be avoided.
 */
    phi = ( (MAX_FRAMES-1)*0.5 - scan_info[1]->center_frame )/
          scan_info[1]->frames_per_radian;

    center[0] = 0.5*cos(phi);
    center[1] = 0.5*sin(phi);
    center[2] = 0.5*( (MAX_DETS-1)*0.5 - scan_info[1]->center_line )
                /scan_info[1]->lines_per_radian;

/* The leading factors of 0.5 are intended to guarantee that center[] has a
 * magnitude less than 1.0. It won't work if center[2] is large, but that won't
 * happen with valid geolocation data. By giving center[] a magnitude less than
 * 1.0, ray[] is guaranteed to have no component larger than 1.0, as required by
 * PGS_CSC_GrazingRay().
 */

/* Convert to ECR coordinates. */
    for(ecr = 0; ecr<3; ecr++)
       for(sc = 0; sc<3; sc++)
          ray[ecr] = ray[ecr] + center[sc]*scan_info[1]->T_ecr2scan[sc][ecr];

    
/* Find the intersection point with the surface of the Earth of a line starting
 * from sc_position, and heading in the direction of ray[], or the nearest point
 * on the surface if there is no intersection.
 */
    retval = PGS_CSC_GrazingRay(EARTH_MODEL, scan_info[1]->sc_position,
             ray, &latitude, &longitude, &missAltitude, &slantRange,  posNEAR, posSURF);
         /* PGSCSC_W_HIT_EARTH is the normal result; PGS_S_SUCCESS is rarer. */

    if ((retval != PGSCSC_W_HIT_EARTH) && (retval !=PGS_S_SUCCESS))
    /* Can only be here as a result of data, coding, or design errors. */
       return MODIS_E_SDST_IGEO_INTERNAL;

    retval = SDST_IGEO_get_orbit_angle(graninfo, posSURF, &orbit_angle);
    if(retval != PGS_S_SUCCESS)
       return retval;

    graninfo->scans_per_radian = (scan_info[1]->iscan - scan_info[0]->iscan)/orbit_angle;

/* Note: any sign ambiguities in the definitions of angles or coordinate
 * systems are corrected for at this point - scans_per_radian can be negative.
 */

    return PGS_S_SUCCESS;
}
