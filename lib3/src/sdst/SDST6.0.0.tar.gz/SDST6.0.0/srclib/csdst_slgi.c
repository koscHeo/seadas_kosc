/** filename csdst_slgi.c **/

#include <stdio.h>
#include <ctype.h>
#include "hdfi.h"
#include "hdf.h"
#include "SDST_SetLGranId.h"

/* Function name redefined for c routines called by FORTRAN */
#define ncsdst_slgi  FNAME(csdst_slgi)

/* function prototype */
void ncsdst_slgi (intf *FPROD_TYPE, _fcd mdHandles, intf *ret);



void ncsdst_slgi (intf *FPROD_TYPE, _fcd MDHANDLES, intf *RET)

/*
***************************************************************************
*!C
*
* !Purpose: 
*
*    This is a wrapping function interfacing between C and FORTRAN for
*    SDST_SetLocalGranId. This C function is only called by the FORTRAN 
*    function SDST_SLGI. This function is an SDST Toolkit internal routine.
*
*
* !Description: 
*
*    Function csdst_slgi is part of a larger software system called the 
*    SDST toolkit abbreviated SDSTTK. SDSTTK consists of in-house
*    developed utility routines to which the MODIS Science Team can link. 
*
*    csdst_slgi is a C function which is callable from FORTRAN. This 
*    function will call SDST_SetLocalGranId. In the SDST toolkit,
*    csdst_slgi is a low-level routine which is called only by SDST_SLGI. 
*
*    In order to be callable from the FORTRAN in different platforms using
*    function name csdst_slgi, this function is called ncsdst_slgi in the 
*    actual C code.
* 
*    ncsdst_slgi is redefined above according to the compilers'
*    FORTRAN naming conventions/conversion for each platform, so that the
*    object name of ncsdst_slgi will always be the object name of a
*    FORTRAN function named csdst_slgi.
*
*
* !Input parameters:
*
*  FPROD_TYPE 	
*          IN:	A constant integer which must be one of the following
*		parameters: L1A, L1B, GEO, L2, L2G, ATMOS, OCEANS, LAND or
*		MAX_PRTYPE.
*
*  mdHandles
*          IN:	A array of character strings. The memory size of the
*		array is: 
*
*		PGSd_MET_NUM_OF_GROUPS * PGSd_MET_GROUP_NAME_L bytes 
*
*		where PGSd_MET_NUM_OF_GROUPS is 20 and PGSd_MET_GROUP_NAME_L 
*		is 50. Each string in the array stores a handle (ASCII name) 
*		to an internal ODL tree structure which will be written out 
*		as an HDF-EOS PVL global attribute. Each handle should be 
*		less than 50 characters. The maximum number of handles should 
*		be 20.
*
*
* !Output parameters:
*         OUT:   FORTRAN integer address of the status
*
*  Returns:
*         none
*
*  Called by:
*         SDST_SLGI located in SDST_TK.f
*
*  Routines Called:
*	  _fcdtocp located in hdf.h
*         SDST_SetLocalGranid located in SDST.h
*
*
* !Revision History:
*         Arvind Solanki  (solanki@ltpmail.gsfc.nasa.gov)
*         GSC SAIC
*         Initial Version
*         January 11, 1999
*
*  Team-unique Header:
*         This software is developed by the MODIS Science Data Support
*         Team for the National Aeronautics and Space Administration, 
*         Goddard Space Flight Center, under contract NAS5-32373.
*
*!END *********************************************************************
*/

{
   /** variable declarations **/

   int 		i,j;
   char 	cvalue[PGSd_MET_NUM_OF_GROUPS][PGSd_MET_GROUP_NAME_L];
   char 	buff[PGS_SMF_MAX_MSGBUF_SIZE];
   char* 	cp;
   char* 	cmdHandles = NULL;


/***************************************************************
*   Call  _fcdtocp to convert MDHANDLES to a C format string.  *
*   Set the return value to cmdHandles.                        *
***************************************************************/


   cmdHandles = (char*)_fcdtocp(MDHANDLES);
   
   
/**************************************************************
*   Convert the FORTRAN strings to C strings for passing to   *
*   SDST_SetLocalGranId.  Do a memory copy and add a NULL     *
*   to the end of the string for C, since it is not there     *
*   in FORTRAN. Do a memcpy, to avoid damaging the actual     *
*   input when the '\0' is inserted at the end of the value.  *
**************************************************************/

   for(i=0; i < 2; i++)
   {
      cp = cmdHandles + i * (PGSd_MET_GROUP_NAME_L - 1);

      for(j = PGSd_MET_GROUP_NAME_L-2; j >= 0 
         && (!isascii(cp[j]) || !isgraph(cp[j])); j--) 
      {
       /*EMPTY*/ ;
      } 
      /*end for*/
	   
      if (j >= 0)
      {
	cvalue[i][0] = '\0';
	memcpy (cvalue[i], cp, (size_t)(j+1));
        cvalue[i][j+1] = '\0';
      }
      else
        cvalue[i][j+1] = '\0';

      /* end if */	

    } /* end for */
    
    
/*******************************************************************
*                                                                  *
*   CALL SDST_SetLocalGranId, to set the localgranuleid attribute  *
*   value, passing FPROD_TYPE(input) and cvalue(input).            *
*                                                                  *
*   Set *RET to the value returned by SDST_SetLocalGranid and then *
*   RETURN to the calling function.                                *
*                                                                  *
*******************************************************************/


   if ((*RET = SDST_SetLocalGranId((enum PROD_TYPE) *FPROD_TYPE, 
 	cvalue)) == FAIL)
   {
	sprintf(buff,"\nERROR: csdst_slgi detected FAIL when  \n"
		     "\t calling function SDST_SetLocalGranid \n"
                     "\t to set the localgranuleid attribute. \n");
   }


   return;
}

/********** END OF FILE csdst_slgi.c **********/
