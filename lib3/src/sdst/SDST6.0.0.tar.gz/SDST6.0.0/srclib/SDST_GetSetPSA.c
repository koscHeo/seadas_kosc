#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "PGS_MET.h"
#include "PGS_SMF.h"
#include "PGS_MET_13.h"
#include "mapi.h"
#include "PGS_MODIS_39604.h"
#include "SDST_GetSetPSA.h"

/* For SDPTK5.2.1 and older toolkits */
#ifndef PGSd_MET_MAX_STRING_SET_L
#define PGSd_MET_MAX_STRING_SET_L 255
#endif



PGSt_SMF_status SDST_GetSetPSA (PGSt_MET_handle mdHandle,
				const char* PSANameStr, void* PSAValue)
/*
!C*****************************************************************************
*
* !Description :
*	Function SDST_GetSetPSA is part of a larger software system
*       called the SDST utility toolkit.  The SDST toolkit (SDSTTK)
*	consists of in-house developed utility routines which the
*	MODIS Science Team can link to.
*
*
*	SDST_GetSetPSA searches for an ADDITIONALATTRIBUTENAME.i that
*	matches the PSANameStr.  If a match is found, it returns the
*	corresponding PARAMETERVALUE.i in the PSA value.
*
* !Input Parameters :
* 	mdHandle : handle for accessing the metadata group containing the PSA
*	PSANameStr : name of the PSA
*
*
* !Output Parameters:
*	PSAValue : value of the PSA (this is always a string)
*
* !Return Value :
* PGS_S_SUCCESS                attributename and PSAValue is successfully
*                              retrived
* PGSMET_E_NO_INITIALIZATION   Metadata file is not initialized
* PGSMET_E_DD_UNKNOWN_PARM     The requested  PSA <ADDITIONALATTRIBUTENAME>
*                              could not be found in <agg ndode>
* PGSMET_W_METADATA_NOT_SET    The metadata <name> is not yet set
* PGSMET_E_NO_DEFINITION       Unable to obtain <attr> of metadata <parameter>
*                              Either NUM_VAL or type is not defined
* PGSMET_E_ILLEGAL _HANDLE     Handle is illegal.  Check that initialization
*                              has taken place
* PGSMET_E_INVALID_LOCATION    Invalid location for setting attribute value
*
*
* !Externally defined:
*	PGS_MET_GetSetAttr
*	
*
* !Called by:
*	SDST_SetLocalGranId
*
*
* !Revision History:
*
* $Log: SDST_GetSetPSA.c,v $
* Revision 5.1  2009/06/26 18:01:26  kuyper
* Improved const-safety.
*
* James Kuyper	James.R.Kuyper@nasa.gov
*
* Revision 1.2  1999/10/13 19:54:51  solanki
* Added macro PGSd_MET_MAX_STRING_SET_L for v5.2.1 and older SDP Toolkits.
*
 * Revision 1.1  1999/09/03  21:48:51  solanki
 * Initial revision
 *
 * Revision 1.1  1999/05/07  19:48:40  jayshree
 * Initial revision
 *
 * Revision 1.6  1999/04/23  14:17:06  jayshree
 * modified prolog
 *
*       Jayshree Murthy
*       04/20/99  Initial Revision
*
*
*
*!Team-unique Header:	
*	This software is developed by the MODIS Science Data Support Team
*	for the National Aeronautics and Space Administration, 
*	Goddard Space Flight Center, under contract NAS5-32373
*
*
*!Design Notes:
*	There are multiple exits from this routine based on the return 
*	status of the PGS Toolkit routines when retrieving metadata.
*
*!END***************************************************************************
*/

{

PGSt_SMF_status  pgs_rtn;
char attrnm[PGSd_MET_MAX_STRING_SET_L] = " ";
char strname[100] = "ADDITIONALATTRIBUTENAME.";
char prmname[100] = "PARAMETERVALUE.";
int i = 0;
char *pattrnm = attrnm;


/* Input checks */

  if (PSANameStr == NULL)
     return(PGSMET_E_INVALID_LOCATION);

  if (PSAValue == NULL)
     return(PGSMET_E_INVALID_LOCATION);
  
 
  do {
        i = i + 1;
           sprintf(strname, "ADDITIONALATTRIBUTENAME.%d",i);
	   strcpy (attrnm, " ");
	   pgs_rtn = PGS_MET_GetSetAttr(mdHandle, strname, &pattrnm);

           if (pgs_rtn != PGS_S_SUCCESS)
           return (pgs_rtn);
 
 }while (strcmp(attrnm,PSANameStr) != 0);
  
   sprintf(prmname, "PARAMETERVALUE.%d", i);
   pgs_rtn = PGS_MET_GetSetAttr(mdHandle, prmname, PSAValue);
 
 return (pgs_rtn);
  
}
    
 
