/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright by  The HDF Group (THG) and                                     *
 *               The Board of Trustees of the University of Illinois.        *
 * All rights reserved.                                                      *
 *                                                                           *
 * This file is part of H4H5TOOLS. The full H4H5TOOLS copyright notice,      *
 * including terms governing use, modification, and redistribution, is       *
 * contained in the files COPYING and Copyright.html.  COPYING can be found  *
 * at the root of the source code distribution tree; Copyright.html can be   *
 * found at the root level of an installed copy of the electronic H4H5TOOLS  *
 * document set and is linked from the top-level documents page.  It can     *
 * also be found at http://www.hdfgroup.org/H4H5TOOLS/doc/Copyright.html.    *
 * If you do not have access to either file, you may request a copy from     *
 * help@hdfgroup.org.                                                        *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#include "h4toh5.h"

/* There are 12 test cases for h4toh5 library.*/
/* h4h5apitestdefault,
   h4h5apitestname,
   h4h5apitestimage,
   h4h5apitestimageattr,
   h4h5apitestsds,
   h4h5apitestsdsattr,
   h4h5apitestvdata,
   h4h5apitestvdataattr,
   h4h5apitestadvgroup,
   h4h5apitestbasvgroup,
   h4h5apitestloneimage,
   h4h5apitestlonesds,
   h4h5apitestlonevdata
   
   This file is h4h5apitestlonevdata:

   1) will test independent vdata conversion API.
  
  
*/

/*-------------------------------------------------------------------------
 * Function:	main
 *
 * Purpose:    
 *-------------------------------------------------------------------------
 */	

 
int main() {

  hid_t         h4toh5id;/* h4toh5 id*/
  int           h4toh5status;/* temporary variable to check the status of h4toh5 APIs. */ 
   
  if((h4toh5id= H4toH5open("vdata_lib_lonetest.hdf","vdata_lib_lonetest.h5",H425_CLOBBER)) < 0) {
    printf("can not open h4toh5 interfaces\n");
    return FAIL;
  }

  if(H4toH5all_lone_vdata(h4toh5id,"/",1)<0) {
    printf(" can not convert all independent image objects\n");
    H4toH5error_get(h4toh5id);
    H4toH5close(h4toh5id);
    return FAIL;
  }

  h4toh5status = H4toH5close(h4toh5id);
  if(h4toh5status == FAIL) {
    printf("cannot close h4toh5 interface.\n");
    return FAIL;
  }

  return 0;
}








