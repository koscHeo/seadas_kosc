H4H5TOOLS version 2.2.2 released on 2013-07-26
Please refer to the release_docs/INSTALL_Unix.txt file for installation
instructions for Unix like platforms and release_docs/INSTALL_Windows.txt for
Windows platforms.

------------------------------------------------------------------------------

This directory includes the source distribution of h4toh5 library and 
conversion tools.

The contents of this directory are:

        COPYING         - Copyright notice
        doc             - Directory with the h4toh5 documentation
        lib             - Directory with h4toh5 library source and testing 
                          code
        misc            - Directory with optional program, an independent
                          tool that verifies data converted to netCDF-4 
        release_docs    - Directory with the release documents
        utils           - Directory with h4toh5 and h5toh4 tools source 
                          and testing code
	README.txt      - This file

Please send questions, comments, and suggestions to:

        help@hdfgroup.org


