#ifndef _PGS_MAPI_39603_H
#define _PGS_MAPI_39603_H
#define MAPI_E_ERR                            324431360 /* 0x13566e00L */
#define MAPI_W_ARN                            324430849 /* 0x13566c01L */
#endif
