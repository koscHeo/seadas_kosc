#ifndef _PGS_MAPI_39602_H
#define _PGS_MAPI_39602_H
#define MAPI_E_ERR                            324423168 /* 0x13564e00L */
#define MAPI_W_ARN                            324422657 /* 0x13564c01L */
#endif
