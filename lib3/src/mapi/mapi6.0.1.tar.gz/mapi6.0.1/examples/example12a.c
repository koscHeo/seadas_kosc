#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mapi.h"
#include "mapic.h"

/*
**  This example program tests function parse_string.
*/

int main(void)
{
  char whole_string1[] = "last_name,first_name,year";
  char whole_string2[] = "123 45 6789";
  char whole_string3[] = "MODIS-MAPI-PGSTK";
  int  n_tokens = 3, found_tokens = 0;
  char *tokens[3];

  printf("\n ********* Example 12a *********\n");
  printf("\n Testing parse_string() ... \n");
  found_tokens = parse_string(whole_string1, ",", n_tokens, tokens);
  printf("Result: %d tokens found.\n", found_tokens);
  printf("These 3 columns are:\n%s|%s|%s|\n", tokens[0], tokens[1], tokens[2]);
  found_tokens = parse_string(whole_string2, " ", n_tokens, tokens);
  printf("\nResult: %d tokens found.\n", found_tokens);
  printf("These 3 columns are:\n%s|%s|%s|\n", tokens[0], tokens[1], tokens[2]);
  found_tokens = parse_string(whole_string3, "-", n_tokens, tokens);
  printf("\nResult: %d tokens found.\n", found_tokens);
  printf("These 3 columns are:\n%s|%s|%s|\n", tokens[0], tokens[1], tokens[2]);
  return 0; 
}
