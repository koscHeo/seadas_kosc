#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "mapi.h"

/*
**  This example program demonstrates how to open a MODIS HDF file,
**  read a given 2-D data array from the file, and close the file.
*/

int main(int argc, char **argv)
{
   MODFILE	*modfile;		/* Modis file pointer */
   void  *data = NULL;			/* Data Array */
   void  *dp;				/* Data Array scanner */
   long dims[2];			/* Array dimensions */
   long sta[2] = {0,0};			/* Array start indices (0-based) */
   long rank = 2;			/* Array rank */
   char dtype[DATATYPELENMAX] = "";	/* Array type */
   char grpnm[] = "";		 	/* Group name */
   long ier;                            /* Error code */
   long i,j;				/* counters */
   float chksum = 0;                    /* check sum of array */

   /* Check calling arguments */
   if (argc != 3)
      {
      printf ("usage : example2a HDF_file_name SDS_name\n");
      return EXIT_FAILURE;
      }

   printf(" *** Example2a ***\n");
   /* Open the MODIS-HDF file */
   modfile= openMODISfile(argv[1], "r");
   if (modfile==NULL){
       printf(" Could not open MODIS-HDF file: %s for reading\n", argv[1]);
       return EXIT_FAILURE;
   }else{
     printf(" File: %s opened for reading only\n", argv[1]);
   }

   /* Get dimensional information about the array */
   ier = getMODISardims(modfile,argv[2],grpnm,dtype,&rank,dims);
   
   printf(" group name = %s\n", grpnm);
   if (ier != MAPIOK){
     printf(" Could not get dimensional information\n");  
   }else{
     printf(" Dimensional data retrieved\n");
   }

   if ((ier == MAPIOK) && (rank == 2))
   {
	data = malloc(dims[0] * dims[1] * MODISsizeof(dtype));

	/* Read the entire array into the data buffer */

       if(getMODISarray(modfile,argv[2],grpnm,sta,dims,data) != MAPIOK)
       {
	   printf("Errors reading array\n");  
	   return EXIT_FAILURE;
       }
   }

   printf(" dtype: %s\n",dtype);
   /* Calculate sum of array and print */
    dp = data;
    for (i=sta[0]; i< (dims[0]+sta[0]); i++)
      for (j=sta[1]; j<(dims[1]+sta[1]); j++){
        chksum +=  *((float*)dp);
	dp = (char *)dp + MODISsizeof(dtype);
      }
    printf(" Array check sum: %5.f \n", chksum);

   /* Close the MODIS-HDF file */
   if(closeMODISfile(&modfile) != MAPIOK || data == NULL)
   {
	free(data);
   	printf (" example2a aborting\n");
	return EXIT_FAILURE;
   }else{
     printf(" File closed successfully\n");
   }
  
   free(data);
   printf (" example2a runs successfully.\n");
   return EXIT_SUCCESS;
}
/* End of example */
