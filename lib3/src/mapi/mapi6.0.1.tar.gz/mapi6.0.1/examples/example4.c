#include <stdio.h>
#include <string.h>
#include "mapi.h"
#include "PGS_MET.h"

#define MCF_FILE 10250

/*
 *   This example program demonstrates opening a new MODIS HDF file, 
 *   setting the ECS metadata, creating a new data array, writing
 *   that array to the HDF file, and closing the HDF file.
 *   Note: This program needs a PCF which contains LUN # 10250.  
 *   This LUN # needs to point to a valid MCF file.
 */

int main(void)
{
  MODFILE      *modfile;          	/* Modis file pointer */
  long dims[3] = {100,20,15};     	/* Array dimensions */
  long dnum = 2;                        /* Dimension number to receive info */
  long sta[3] = {0, 0, 0};           	/* Array start indices (0-based) */
  long rank = 3;			/* Array rank */
  char dtype[] = I32;			/* Array type, set to M-API macro */
  char arrnm[] = "DATASHORT"; 		/* Array name */
  char attr[]  = MLONG_NAME;           /* Array attribute, set to M-API macro*/
  char attrv[] = "some really long name";         /* Array attribute value */
  char atype[] = TXT;                  /* Array attribute data type */
  char grpnm[] = "\0";                 /* Group name */
  char fname[] = "arrex4.hdf";         /* File name */
  char acc_mode[] = "w";               /* File access mode */
  int i,j;                           /* counters */
  int32 idata[20][15];            	/* Data Array */
  long NumHandles = 1;
  PGSt_MET_all_handles mdhandles;
  ECSattr_names_for_all_handles HDFattrNames;
  int  ret_val = EXIT_SUCCESS;
  
  printf("\n *** Example4 ***\n");
  
  for( i=0;i < 20; i++)
    for (j=0; j< 15; j++)
       idata[i][j] = (int32)1;

  strcpy (HDFattrNames[1], MECS_CORE);

  if(PGS_MET_Init(MCF_FILE, mdhandles) != PGS_S_SUCCESS)
  {
    printf("error in PGS_MET_Init %d\n",ret_val);
    return EXIT_FAILURE;
  }

  /* Create the MODIS-HDF file */
  modfile= openMODISfile(fname,acc_mode);
  if (modfile==NULL)
  {
    printf("Error opening: %s\n",fname);
    ret_val = EXIT_FAILURE;
  }else{
    printf("File: %s, opened.\n",fname);
  }
  /* Create array */
  if(createMODISarray(modfile,arrnm,grpnm,dtype,rank,dims) == MAPIOK)
  {
    printf("Array created: %s\n",arrnm);
    /*  Label the last dimension                             */
    if(putMODISdiminfo(modfile, arrnm, grpnm, dnum, attr, atype,
	(long)strlen(attrv),(void *) attrv) != MAPIOK)
    {
      fprintf (stderr, "Error putting diminfo: exiting\n");
      ret_val = EXIT_FAILURE;
    }else{
      printf("Dimension %ld, putting attribute info: %s = %s\n",
	  dnum,attr,attrv);
    }
    /*  Re-define the last dimension for writing the array */
    dims[0] = 1;                                       
    
    /*  Loop on the last dimension to write the array. */
    for (i=0; i < 100; i++)
    { /*  Set the start index for the last dimension and write to the array */
      sta[0] = i;
      if(putMODISarray(modfile,arrnm,grpnm,sta,dims,(void *)idata) != MAPIOK)
	  break;
    }
    if (i < 100)
    {
      fprintf (stderr, "Error writing array, exiting\n");
      ret_val = EXIT_FAILURE;
    }else{
      printf("Array written: %s\n",arrnm);
    } 
  }
  /* Close the MODIS-HDF file */
  if(completeMODISfile(&modfile, mdhandles, HDFattrNames, NumHandles) != MAPIOK)
  {
    printf("Error closing file, exiting\n");
    ret_val = EXIT_FAILURE;
  }else{
    printf("File closed successfully.\n");
  }

  return ret_val;
}
