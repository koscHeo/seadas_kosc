#include <stdio.h>
#include <string.h>
#include "mapi.h"

/*
**    This program will create a modis HDF table called "Bolide Heights" 
**    using createMODIStable, then put the 3 records of information in 
**    to the table using putMODIStable.
*/

int main(void)
{
   unsigned char    data1[12];	/* data buffer */
   MODFILE          *mfile;	/* pointer to MODIS-HDF file */
				/* data structure */
   long int	    recno = 1;  /* Number of records to write */
   long int	    start = -1; /* Location of first record to write to */
				/* (-1 indicates to append to existing  */
				/* records */
   char		    *tablename = "Bolide Heights";
   char		    *groupname  = NULL;
   char		    *classname = "Fake Data class";   /* Table field names */
   char		    *fieldnames ="Latitude(deg),Longitude(deg),Altitude(m)";

/* Field data types */
   char		    *datatypes = R32 "," R32 "," I32;
   char             fname[16] = "tblex6a.hdf";        /* Modis file name */
   char             faccess[] = "w";                /* Modis file access */
   /* Data arrays */
   float            lat[3] = { 40.50, -22.81, 08.10};
   float	    lon[3] = {-80.22, -43.25, 98.32};
   int              height[3] = {400, 400, 400};
   int	            i;
   long NumHandles = 0;


   printf(" *** Example6a ***\n");

   /* Open the MODIS-HDF file */
   mfile = openMODISfile(fname, faccess);
   if (mfile==NULL){
      printf("Error openning %s exiting \n",fname);
      return EXIT_FAILURE;
   }else{
     printf("File: %s opened, access mode %s\n",fname,faccess);
   }

   /* Create table */
   if(createMODIStable(mfile,tablename,classname,groupname,fieldnames,
       datatypes) != MAPIOK)
   {
      printf("Error creating table, exiting\n");
      return EXIT_FAILURE;
   }else{
     printf("Table created, Name: %s,\n",tablename);
   }

   /* Put the data into the modis HDF table. Write 1 record    */
   /* at a time, always append it at the end of the table(-1). */
   recno = 1;
   start = -1;
   for (i = 0; i < 3; i++)
   {
	memcpy(data1, lat + i, sizeof(float));
	memcpy(data1 + sizeof(float), lon + i, sizeof(float));
        memcpy(data1 + 2*sizeof(float), height + i, sizeof(int));
        if(putMODIStable(mfile,tablename,groupname,start,recno,data1) != MAPIOK)
	    break;
   }   
   if (i < 3){
     printf("Error writing table, exiting\n");
     return EXIT_FAILURE;
   }else{
     printf("Put the table in the file...\n");
   }

   /* Close the MODIS-HDF file */
   if(completeMODISfile(&mfile, NULL, NULL, NumHandles) != MAPIOK)
   {
      printf("Error closing file, exiting\n");
      return EXIT_FAILURE;
   }else{
     printf("File closed successfully\n");
   }

   return EXIT_SUCCESS;
}
