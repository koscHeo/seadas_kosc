#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "mapi.h"

/*
**  This example program demonstrates how to open a MODIS HDF file,
**  read a single ECS metadata field from the file, parse into  
**  individual strings, and close the file.
*/

int main(void)
{
   MODFILE	*modfile;                    /* Modis file pointer */
   long int n_elements=20l;                  /* Number of metadata values
                                                 to extract from value. */
   void *value;
   char access_mode[]="r";
   int  ier;					/* Error code */
   int  i;
   long int  n_strings=10;
   char *substr[10];
   int  size = 256;

   char filename[]="arrex4.hdf";              /* Input file */
   char PVLAttrName[]= MECS_CORE;             /* PVL Attribute name input */
   char parmName[] =  MCORE_SHORT_NAME;       /* parameter name */
   char data_type[] = TXT;               /* Data type off
						 the parameter value */
   printf(" *** Example 9 ***\n");
   /* Allocate memory for value. */
   value = (void *)malloc(size);

   /* Open the MODIS-HDF file */
   modfile= openMODISfile(filename, access_mode);

   if (modfile==NULL) {
     printf("Unable to open file %s\n",filename);
     return 1;
   }else{
     printf("Opening the file\n");
   }
   ier = getMODISECSinfo(modfile, PVLAttrName, parmName, data_type,
       &n_elements, value);
   if(ier != MAPIOK)
   {
     printf("ier(getMODISECSinfo) = %d\n",ier);
     printf("n_elements = %ld\n",n_elements);
     printf("data_type = %s\n",data_type);
     printf("PVLAttrName = %s\n",PVLAttrName);
     printf("parmName = %s\n",parmName);
   }else{
     printf("n_elements = %ld\n",n_elements);
     printf("data_type = %s\n",data_type);
   }
   if ( (ier == MAPIOK) && ( n_elements != 0 ) ){ 
     if ( strcmp(data_type, I32) == 0 )
       for (i=0; i < n_elements; i++)
         printf("value = %ld ", (long)((int32 *)value)[i]);
     if (strcmp(data_type, R32) == 0)
       for (i=0; i < n_elements; i++)
         printf("value = %f ", (double)((float32 *)value)[i]);
     if (strcmp(data_type, R64) == 0)
       for (i=0; i < n_elements; i++)
         printf("value = %f ", (double)((float64 *)value)[i]);
     printf("\n");
     if (strcmp(data_type, TXT) == 0)
     {
       if(substrMODISECSinfo(value,n_elements,&n_strings,substr) != MAPIOK)
       {
	 printf("ier(substrMODISECSinfo) = %d\n",ier);
	 printf("Error printing the substrings\n");
       }else{
	 printf("n_strings = %ld\n", n_strings);
	 printf("string(s) = \n");
	 for (i=0;i<n_strings;i++)
	   printf("%s\n",substr[i]);	
       }
     }
   }

   /* Close the MODIS-HDF file */
   if(closeMODISfile(&modfile) != MAPIOK)
   {
       printf("Error closing file\n");
       return 1;
   }else{
       printf("File closed.\n");
       return 0;
   }
}
/* End of example9 */
