#include <stdlib.h>
#include <stdio.h>
#include "mapi.h"

/*    This example program demonstrates how to open a new MODIS HDF file, 
      create a data array in a Vgroup, write data to the array, put a 
      dimension name to the first dimension of it, and close the MODIS HDF 
      file. */

int main(void)
{
   MODFILE	*modfile;		/* Modis file pointer */
   float32 data[64][32];                /* Data Array */
   float32 cksum = 0.0;                 /* array check sum  */
   long dims[2] = {64,32};		/* Array dimensions */
   long sta[2]  = {0,0};		/* Array start indices (0-based) */
   long rank    = 2;			/* Array rank */
   char arrnm[] = "DFLOAT";		/* Array name */
   char grpnm[] = "Qi_group";		/* Group name */
   char fname[] = "arrex2.hdf";         /* Modis file name */
   char faccess[] = "w";                /* Modis file access */
   int i,j;				/* counters */
   long NumHandles = 0;

   printf(" *** Example2 ***\n");

   /* open the file */
   modfile= openMODISfile(fname, faccess);
   if (modfile==NULL)
   {
      printf ("Error openning %s, exiting \n",fname);
      return EXIT_FAILURE;
   }
   else
     printf(" File: %s opened, access mode %s\n",fname,faccess);
 
   if(createMODISgroup(modfile, grpnm, NULL) != MAPIOK)
   {
      printf ("Error creating group, exiting\n");
      return EXIT_FAILURE;
   }
   else
     printf(" Group created, Name: %s,\n", grpnm);

   if(createMODISarray(modfile, arrnm, grpnm, R32, rank, dims) != MAPIOK)
   {
      printf ("Error creating array, exiting\n");
      return EXIT_FAILURE;
   }
   else
     printf(" Array created, Name: %s,\n",arrnm);
 
   /* Put dimnesion name to the array */
   if(putMODISdimname(modfile, arrnm, grpnm, 0, "Wade_dimension") != MAPIOK)
   {
       printf("Error writing dimension name, exiting\n");
       return EXIT_FAILURE;
   }
   else
       printf("putMODISdimname is successful\n");

   /* Write to the array (note that the entire array is being
      written, so data dimensions are equal to array dimensions */
   
   for (i=0; i< dims[0]; i++)
     for (j=0; j< dims[1]; j++)
     {
       data[i][j]= (float32)((i+j) + 1000.0);
       cksum = cksum + data[i][j];
     }

   if(putMODISarray(modfile,arrnm,grpnm,sta,dims,data) != MAPIOK)
   {
     printf ("Error writing array, exiting\n");
     return EXIT_FAILURE;
   }
   else
   {
     printf(" Array check sum: %f \n",cksum);
     printf(" Put the array in the file...\n");
   }

   /* Close the MODIS-HDF file */
   if(completeMODISfile(&modfile, NULL, NULL, NumHandles) != MAPIOK)
   {
      printf ("Error closing file, exiting\n");
       return EXIT_FAILURE;
   }else{
     printf(" File closed successfully\n");
   }
   printf("\n");
   return 0;
}
/* End of example */
