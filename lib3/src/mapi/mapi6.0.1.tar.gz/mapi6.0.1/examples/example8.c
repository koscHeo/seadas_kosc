#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "mapi.h"

/*
**  This example program demonstrates how to open a MODIS HDF file,
**  read a single field from a given data table from the file, 
**  and close the file.
*/

int main(void)
{
    MODFILE	*modfile;		/* Modis file pointer */
    void	*data = NULL;			/* Data Array */
    void *dp;				/* Data Array scanner */
    char *field_dtype;		        /* Table field's data type */
    char *fieldnames ="";       	/* Table's field names */
    char *next_field;			/* The next field name */
    char *datatypes = "";		/* their data types */
    char *next_type;			/* The next data type */
    char *fname = "tblex6.hdf";            /* Input file name */
    char *vname = "Bolide Heights";        /* Vdata name */
    long int stringlen;			/* The length these strings need to be*/
    long int records;			/* Number of records in the table and */
    long int fields;			/* Number of fields (columns) in it */
    char *single_fieldname;		/* Single field name extracted from */
    /* fieldnames			    */
    char *grpnm = "";			/* Group name */
    long int size_of_buffer;	        /* Size of buffer used to get data */
    long int sta = 0;			/* First record in table to read*/
    int i;				/* counter */
    int status=EXIT_SUCCESS;		/* Exit status */
    
    printf(" *** Example8 ***\n");
    /* Open the MODIS-HDF file */
    modfile = openMODISfile(fname, "r");
    if (modfile==NULL){
      printf("File %s not found\n", fname);
      return EXIT_FAILURE;
    }else{
      printf("File: %s opened.\n",fname);
    }
    /* Get size of strings required to hold field names and data type info */
    /* getMODISfields will return MFAIL because the strings are too short (0) */
    /* but stringlen should return the length required.			  */
    /* Note that fieldnames and datatypes must NOT be set to NULL for the  */
    /* string length information to be returned				  */
    
    stringlen = 0;
    (void)getMODISfields(modfile,vname,grpnm,&stringlen,NULL,NULL,
			 fieldnames,datatypes,NULL);
    if (stringlen == 0){
      printf ("Table not found\n");
    }else{
      fieldnames = (char *)malloc(stringlen * sizeof(char));
      datatypes = (char *)malloc(stringlen * sizeof(char));
      
      /* Get dimensional information about the table */
      if(fieldnames==NULL || datatypes==NULL)
      {
	printf("malloc() failed.\n");
	status = EXIT_FAILURE;
      }
      else if(getMODISfields(modfile,vname,grpnm,&stringlen,&records,
			 &fields,fieldnames,datatypes,NULL) == MAPIOK)
      {
	printf("Each of the %ld records contains these fields: %s\n",
	       records, fieldnames);
	
	/* get the data type of the specified field
	   determine the field number of the specified field */
	/* get the data type of the field from the datatypes string */
	single_fieldname = fieldnames;
	field_dtype = datatypes;

	while(single_fieldname != NULL) {
	  next_field = strchr(single_fieldname, ',');
	  if(next_field)
	      *next_field++ = '\0';

	  next_type = strchr(field_dtype, ',');
	  if(next_type)
	      *next_type++ = '\0';

	  printf("FieldName: %s \tField datatype: %s\n",
	      single_fieldname,field_dtype);
	  
	  /* allocate an array to retrieve the data. Note that since the 
	     data to be retrieved are all of the same data type,         
	     extracting the data from a generic byte buffer is not required.*/
	  size_of_buffer = records * MODISsizeof(field_dtype);
	  data = (void *)malloc(size_of_buffer);
	  if(data==NULL)
	  {
	      printf("malloc() failed.\n");
	      status = EXIT_FAILURE;
	  }
	  /* Read field from every record in the table into the data buffer */
	  else if(getMODIStable(modfile,vname,grpnm,single_fieldname,
			      sta,records,&size_of_buffer,data) == MAPIOK)
	  {
	    /* List contents of array */
	    dp = data;
	    for (i= 0; i < records; i++){
	      if (strcmp(field_dtype,I8) == 0)
		printf ("record %d = %d\n",i,(int) *((int8 *)dp));
	      else if (strcmp(field_dtype,UI8) == 0)
		printf ("record %d = %u\n",i,(unsigned int) *((uint8 *)dp));
	      else if (strcmp(field_dtype,I16) == 0) 
		printf ("record %d = %d\n",i, (int) *(int16 *)dp);
	      else if (strcmp(field_dtype,UI16) == 0) 
		printf ("record %d = %u\n",i, (unsigned) *(uint16 *)dp);
	      else if (strcmp(field_dtype,I32) == 0)
		printf ("record %d = %ld\n",i, (long)*(int32 *)dp);
	      else if (strcmp(field_dtype,UI32) == 0)
		printf ("record %d = %lu\n",i, (unsigned long)*(uint32 *)dp);
	      else if (strcmp(field_dtype,R32) == 0)
		printf ("record %d = %g\n",i, (double)*((float32 *)dp));
	      else if (strcmp(field_dtype,R64) == 0)
		printf ("record %d = %g\n",i, (double)*((float64 *)dp));
	      else if (strcmp(field_dtype,TXT) == 0)
		printf ("record %d = %c\n",i,(int) *((char *)dp)); 
	      dp = (char *)dp + MODISsizeof(field_dtype);
	    }
	  }else
	    printf("Error calling getMODIStable.\n");

	  free(data);
	  single_fieldname = next_field;
	  field_dtype = next_type;
	}
      }
      free(fieldnames);
      free(datatypes);
    }
    /* Close the MODIS-HDF file */
    if(closeMODISfile(&modfile) != MAPIOK)
    {
	printf ("Error closing file\n");
	return EXIT_FAILURE;
    }else{
	printf ("File closed\n");
    }
    return status;
}
/* End of example */
