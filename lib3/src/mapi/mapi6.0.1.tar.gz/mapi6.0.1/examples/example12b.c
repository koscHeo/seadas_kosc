#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mapi.h"
#include "mapic.h"

/*
**  This example program tests functions
**  MODISsizeof, MTYPEc2f, and MTYPEf2c.
** $Log: example12b.c,v $
** Revision 6.1  2010/07/13 15:17:57  kuyper
** Corrected declaration of main().
**
** Revision 5.1  2005/04/07 16:07:32  vlin
** vlin@saicmodis.com
**
*/

int main(void)
{
  char FORTRAN_cd_ty[64] = "";
  char C_fd_ty[64] = "";
  int  rtn = -1;
  long int         byte_sum = 0L, f_len = 100L, c_len = 100L;

  printf("\n ********* Example 12b *********\n");
  printf(" Testing MODISsizeof() ...\n");
  byte_sum = MODISsizeof("float32,float32,int32,int32");
  printf("Total number of bytes returned = %ld (expect 16)\n", (long)byte_sum);

  printf("\n Testing MTYPEf2c() ...\n");
  rtn = MTYPEf2c("REAL*4,INTEGER*1,UINTEGER*2,REAL*8", C_fd_ty, &c_len);
  printf("returned C datatypes = %s\n", C_fd_ty);
  printf("returned length = %ld (expect 28)\n", (long)c_len);
  printf("MTYPEf2c returns %d\n", rtn);

  printf("\n Testing MTYPEc2f() ...\n");
  rtn = MTYPEc2f("int8,int16,float32,uint16", FORTRAN_cd_ty, &f_len);
  printf("returned FORTRAN datatypes = %s\n", FORTRAN_cd_ty);
  printf("returned length = %ld(expect 38)\n", (long)f_len);
  printf("MTYPEc2f returns %d\n", rtn);
  printf("\n ********* End of example12a and 12b *********\n");
  return 0; 
}
