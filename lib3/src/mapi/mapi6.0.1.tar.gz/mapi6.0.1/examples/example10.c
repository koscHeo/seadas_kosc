#include <stdio.h>
#include <stdlib.h>
#include "mapi.h"
#include "hdf.h"
#include "HdfEosDef.h"

/*
**  This example program demonstrates how to open a HDF-EOS file,
**  create a simple swath, get the MAPI filehandle from the swath
**  file handle, write an array to the file, release the MAPI filehandle,
**  and close the  HDF-EOS file. 
*/

int main(void)
{
    char filename[] = "swath10.hdf";
    intn access =  DFACC_CREATE;
    long int start[3] = {0,0,0};
    long int dimsizes[3] = {2,3,3};
    int8 data[2][3][3];
    int32 swfid;
    int	i,j,k;
    MODFILE	*mfile;

    printf(" *** Example10 ***\n");

    if ((swfid = SWopen(filename,access)) == FAIL){
	printf("SWopen fails\n");
	return EXIT_FAILURE;
    } else
	printf("Swath file %s successfully openned!\n", filename);

    if (SWcreate(swfid, "Example_Swath") == FAIL)
    {
	printf("SWcreate fails\n");
	return EXIT_FAILURE;
    } else
	printf("Swath successfully created!\n");

    if ( (mfile = createMAPIfilehandle(swfid)) == NULL)
    {
      printf("createMAPIfilehandle fails\n");
      return EXIT_FAILURE;
    } else
	printf("MAPI filehandle successfully created!\n");

    if (createMODISgroup(mfile,"Qi_group","Yale_class") != MAPIOK)
    {
      printf("createMODISgroup fails\n");
      return EXIT_FAILURE;
    } else
	printf("MODIS group created!\n");

    if (createMODISarray(mfile,"Wade_array","Qi_group",I8,3,dimsizes) != MAPIOK)
    {
      printf("createMODISarray fails\n");
      return EXIT_FAILURE;
    }else {
      /* Set value for data */
      for (i=0;i<2;i++)
	for (j=0;j<3;j++)
	  for (k=0;k<3;k++)
	    data[i][j][k] = i+j+k;
    }

    /* Write data to array */
    if(putMODISarray(mfile,"Wade_array","Qi_group",start,dimsizes,data)
	!= MAPIOK)
    {
	printf("putMODISarray fails\n");
	return EXIT_FAILURE;
    } else
	printf("Data was successfully written to the file!\n");

    /* Release MAPI file handle */
    if (releaseMAPIfilehandle(&mfile) != MAPIOK)
    {
      printf("releaseMAPIfilehandle fails\n");
      return EXIT_FAILURE;
    } else
	printf("MAPI filehandle released successfully!\n");

    printf("swfid = %ld\n", (long)swfid);

    if (SWclose(swfid) != SUCCEED)
    {
	printf("SWclose fails\n");
	return EXIT_FAILURE;
    } else
	printf("Swath file successfully closed!\n");

    return 0;
}
